from flask import Flask, request, jsonify
import os, shutil, uuid, tarfile

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 1024  # Limit upload size to 1KB

@app.route('/untar', methods=['POST'])
def untar_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']

    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if file and (file.filename.endswith('.tar')):
        user_id = uuid.uuid4().hex
        upload_id = uuid.uuid4().hex
        UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads', user_id, upload_id)
        try:
            with tarfile.open(fileobj=file, mode='r') as tar:
                tar.extractall(path=UPLOAD_FOLDER)
            return jsonify({'message': 'File untarred successfully'}), 200
        except Exception as e:
            return jsonify({'error': 'File untarred unsuccessfully'}), 500
        finally:
            shutil.rmtree(os.path.join(os.getcwd(), 'uploads', user_id), ignore_errors=True)
    else:
        return jsonify({'error': 'Invalid file type. Only TAR files are allowed.'}), 400

@app.errorhandler(413)
def request_entity_too_large(error):
    return jsonify({'error': 'File too large. Max size is 1KB.'}), 413

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
    