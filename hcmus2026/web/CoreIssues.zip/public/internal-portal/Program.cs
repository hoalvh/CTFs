using Chall.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Logging.SetMinimumLevel(LogLevel.Warning);
builder.WebHost.ConfigureKestrel(options =>
{
    options.Limits.MaxRequestBodySize = 128 * 1024;
});

builder.Services.AddControllersWithViews();
builder.Services.AddSingleton<PortalDataStore>();
builder.Services.AddSingleton<AuditTrailService>();
builder.Services.AddSingleton<CaseWorkflowService>();
builder.Services.AddSingleton<IntegrationRegistryService>();
builder.Services.AddSingleton<ReportExportService>();
builder.Services.AddSingleton<ApprovalWorkflowService>();
builder.Services.AddSingleton<NotificationCenterService>();
builder.Services.AddSingleton<PortalSettingsService>();
builder.Services.AddSingleton<RuleEvaluationService>();
builder.Services.AddSingleton<WorkbenchSearchService>();
builder.Services
    .AddAuthentication(PortalAuth.AuthScheme)
    .AddCookie(PortalAuth.AuthScheme, options =>
    {
        options.Cookie.Name = PortalAuth.CookieName;
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.SecurePolicy = CookieSecurePolicy.None;
        options.LoginPath = "/";
        options.AccessDeniedPath = "/";
        options.SlidingExpiration = false;
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
    });
builder.Services.AddAuthorization();

var app = builder.Build();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.Use(async (context, next) =>
{
    if (context.Request.Path.StartsWithSegments("/api")
        && context.User.Identity?.IsAuthenticated != true)
    {
        await PortalAuth.EnsureModeratorSessionAsync(context);
    }

    await next();
});
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Portal}/{action=Dashboard}/{id?}");

app.Run();
