using Chall.Models;

namespace Chall.Services;

public sealed class PortalDataStore
{
    private readonly object _gate = new();
    private readonly List<CaseRecord> _cases = [];
    private readonly List<IntegrationRecord> _integrations = [];
    private readonly List<ExportJob> _exports = [];
    private readonly List<ApprovalRequest> _approvals = [];
    private readonly List<AuditEvent> _audit = [];
    private readonly List<NotificationItem> _notifications = [];
    private readonly List<PolicyRule> _rules = [];
    private readonly List<DocumentRecord> _documents = [];
    private readonly Dictionary<string, PortalSetting> _settings = new(StringComparer.OrdinalIgnoreCase);

    public PortalDataStore()
    {
        var now = DateTimeOffset.UtcNow;
        _cases.AddRange([
            Case("MR-2841", "Northstar Labs", "Velocity anomaly", "Payments", "waiting", "admin", "high", "APAC", 82420, now.AddMinutes(-18)),
            Case("MR-2837", "Copperline Co", "Policy review", "Merchant Risk", "triage", "northdesk", "medium", "APAC", 12950, now.AddMinutes(-41)),
            Case("MR-2828", "Alpine Market", "Document mismatch", "Onboarding", "ready", "integrations", "low", "EMEA", 4300, now.AddHours(-1).AddMinutes(-12)),
            Case("MR-2819", "Beacon Supply", "High-value transfer", "Payments", "escalated", "trust.ops", "critical", "APAC", 162000, now.AddHours(-2).AddMinutes(-4)),
            Case("MR-2811", "Evergreen Shop", "Duplicate profile", "Identity", "triage", "admin", "medium", "AMER", 5700, now.AddHours(-2).AddMinutes(-17)),
            Case("MR-2804", "Harvest Point", "New merchant review", "Onboarding", "waiting", "northdesk", "medium", "APAC", 22100, now.AddHours(-3).AddMinutes(-8)),
        ]);

        _integrations.AddRange([
            Integration("partner-inventory", "Partner Inventory", "staging", "integrations@example.test", "healthy", "green", "https://inventory.internal.example", now.AddMinutes(-6), 0),
            Integration("merchant-ledger", "Merchant Ledger", "production", "finance@example.test", "healthy", "green", "https://ledger.internal.example", now.AddMinutes(-11), 0),
            Integration("case-enrichment", "Case Enrichment", "sandbox", "ops@example.test", "degraded", "amber", "https://enrich.internal.example", now.AddMinutes(-27), 3),
            Integration("identity-archive", "Identity Archive", "production", "trust@example.test", "healthy", "green", "https://archive.internal.example", now.AddMinutes(-33), 0),
            Integration("review-export", "Review Export", "production", "compliance@example.test", "scheduled", "blue", "https://exports.internal.example", now.AddHours(-2), 0),
        ]);

        _exports.AddRange([
            Export("ex_1001", "compliance-package", "csv", "system", "complete", now.AddHours(-8), now.AddHours(-8).AddMinutes(4)),
            Export("ex_1002", "operations-rollup", "json", "admin", "complete", now.AddHours(-3), now.AddHours(-3).AddMinutes(2)),
            Export("ex_1003", "partner-exceptions", "xlsx", "system", "queued", now.AddMinutes(-22), null),
        ]);

        _approvals.AddRange([
            Approval("ap_9001", "Beacon Supply transfer review", "payments", "admin", "pending", now.AddMinutes(-38)),
            Approval("ap_9002", "Case enrichment production access", "integration", "integrations", "pending", now.AddHours(-1)),
        ]);

        _notifications.AddRange([
            Notification("nt_2001", "admin", "Queue threshold reached", "Payments queue crossed the 120 case threshold.", "queue", false, now.AddMinutes(-25)),
            Notification("nt_2002", "admin", "Partner sync degraded", "Case Enrichment reported three failed sync attempts.", "integration", false, now.AddMinutes(-19)),
            Notification("nt_2003", "trust.ops", "Approval waiting", "Beacon Supply transfer review is waiting for decision.", "approval", false, now.AddMinutes(-38)),
        ]);

        _rules.AddRange([
            Rule("rl_3001", "High value transfer", "case", "amount", "gte", "100000", "escalate", true),
            Rule("rl_3002", "APAC identity review", "case", "region", "eq", "APAC", "manual-review", true),
            Rule("rl_3003", "Degraded integration", "integration", "health", "eq", "amber", "notify-owner", true),
            Rule("rl_3004", "Production owner required", "integration", "environment", "eq", "production", "require-owner", true),
        ]);

        _documents.AddRange([
            Document("doc_7001", "Quarterly role review", "compliance", "internal", "current", now.AddDays(-2), ["roles", "audit"]),
            Document("doc_7002", "Partner connector runbook", "integrations", "internal", "current", now.AddDays(-4), ["connector", "runbook"]),
            Document("doc_7003", "Payment escalation matrix", "trust.ops", "restricted", "draft", now.AddHours(-7), ["payments", "escalation"]),
        ]);

        PutSetting(new PortalSetting { Key = "review.batch.size", Value = "50", Group = "workflow", RequiresAdmin = false, UpdatedAt = now });
        PutSetting(new PortalSetting { Key = "integration.preview.timeout", Value = "30", Group = "integration", RequiresAdmin = true, UpdatedAt = now });
        PutSetting(new PortalSetting { Key = "exports.retention.days", Value = "14", Group = "reports", RequiresAdmin = true, UpdatedAt = now });
    }

    public List<CaseRecord> Cases()
    {
        lock (_gate)
        {
            return _cases.Select(Clone).ToList();
        }
    }

    public CaseRecord? Case(string id)
    {
        lock (_gate)
        {
            return _cases.FirstOrDefault(item => item.Id.Equals(id, StringComparison.OrdinalIgnoreCase)) is { } found ? Clone(found) : null;
        }
    }

    public CaseRecord? UpdateCase(string id, Func<CaseRecord, bool> update)
    {
        lock (_gate)
        {
            var found = _cases.FirstOrDefault(item => item.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (found == null || !update(found))
            {
                return null;
            }

            found.UpdatedAt = DateTimeOffset.UtcNow;
            return Clone(found);
        }
    }

    public List<IntegrationRecord> Integrations()
    {
        lock (_gate)
        {
            return _integrations.Select(Clone).ToList();
        }
    }

    public IntegrationRecord? Integration(string id)
    {
        lock (_gate)
        {
            return _integrations.FirstOrDefault(item => item.Id.Equals(id, StringComparison.OrdinalIgnoreCase)) is { } found ? Clone(found) : null;
        }
    }

    public IntegrationRecord? UpdateIntegration(string id, Func<IntegrationRecord, bool> update)
    {
        lock (_gate)
        {
            var found = _integrations.FirstOrDefault(item => item.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (found == null || !update(found))
            {
                return null;
            }

            return Clone(found);
        }
    }

    public List<ExportJob> Exports()
    {
        lock (_gate)
        {
            return _exports.Select(Clone).ToList();
        }
    }

    public ExportJob AddExport(ExportJob job)
    {
        lock (_gate)
        {
            _exports.Insert(0, job);
            return Clone(job);
        }
    }

    public ExportJob? Export(string id)
    {
        lock (_gate)
        {
            return _exports.FirstOrDefault(item => item.Id.Equals(id, StringComparison.OrdinalIgnoreCase)) is { } found ? Clone(found) : null;
        }
    }

    public List<ApprovalRequest> Approvals()
    {
        lock (_gate)
        {
            return _approvals.Select(Clone).ToList();
        }
    }

    public ApprovalRequest AddApproval(ApprovalRequest approval)
    {
        lock (_gate)
        {
            _approvals.Insert(0, approval);
            return Clone(approval);
        }
    }

    public ApprovalRequest? UpdateApproval(string id, Func<ApprovalRequest, bool> update)
    {
        lock (_gate)
        {
            var found = _approvals.FirstOrDefault(item => item.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (found == null || !update(found))
            {
                return null;
            }

            return Clone(found);
        }
    }

    public List<AuditEvent> Audit()
    {
        lock (_gate)
        {
            return [.. _audit];
        }
    }

    public void AddAudit(AuditEvent auditEvent)
    {
        lock (_gate)
        {
            _audit.Insert(0, auditEvent);
            if (_audit.Count > 500)
            {
                _audit.RemoveRange(500, _audit.Count - 500);
            }
        }
    }

    public List<NotificationItem> Notifications(string? recipient = null)
    {
        lock (_gate)
        {
            return _notifications
                .Where(item => recipient == null || item.Recipient.Equals(recipient, StringComparison.OrdinalIgnoreCase))
                .Select(Clone)
                .ToList();
        }
    }

    public void AddNotification(NotificationItem item)
    {
        lock (_gate)
        {
            _notifications.Insert(0, item);
        }
    }

    public NotificationItem? UpdateNotification(string id, Func<NotificationItem, bool> update)
    {
        lock (_gate)
        {
            var found = _notifications.FirstOrDefault(item => item.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (found == null || !update(found))
            {
                return null;
            }

            return Clone(found);
        }
    }

    public List<PolicyRule> Rules()
    {
        lock (_gate)
        {
            return _rules.Select(Clone).ToList();
        }
    }

    public List<DocumentRecord> Documents()
    {
        lock (_gate)
        {
            return _documents.Select(Clone).ToList();
        }
    }

    public DocumentRecord AddDocument(DocumentRecord document)
    {
        lock (_gate)
        {
            _documents.Insert(0, document);
            return Clone(document);
        }
    }

    public List<PortalSetting> Settings()
    {
        lock (_gate)
        {
            return _settings.Values.Select(Clone).OrderBy(item => item.Group).ThenBy(item => item.Key).ToList();
        }
    }

    public PortalSetting PutSetting(PortalSetting setting)
    {
        lock (_gate)
        {
            _settings[setting.Key] = Clone(setting);
            return Clone(setting);
        }
    }

    private static CaseRecord Case(string id, string customer, string signal, string queue, string status, string owner, string priority, string region, decimal amount, DateTimeOffset created)
    {
        return new CaseRecord
        {
            Id = id,
            Customer = customer,
            Signal = signal,
            Queue = queue,
            Status = status,
            Owner = owner,
            Priority = priority,
            Region = region,
            Amount = amount,
            CreatedAt = created,
            UpdatedAt = created,
            Notes = [new CaseNote($"note_{id.ToLowerInvariant()}", "system", "Case imported from queue monitor.", true, created)],
            History = [new CaseEvent("created", "system", signal, created)],
        };
    }

    private static IntegrationRecord Integration(string id, string name, string environment, string owner, string status, string health, string baseUrl, DateTimeOffset lastSync, int errorCount)
    {
        return new IntegrationRecord
        {
            Id = id,
            Name = name,
            Environment = environment,
            OwnerEmail = owner,
            Status = status,
            Health = health,
            BaseUrl = baseUrl,
            LastSync = lastSync,
            ErrorCount = errorCount,
            Metadata = new Dictionary<string, string>
            {
                ["sla"] = environment == "production" ? "99.9" : "best-effort",
                ["region"] = "apac",
            },
        };
    }

    private static ExportJob Export(string id, string type, string format, string requestedBy, string status, DateTimeOffset requestedAt, DateTimeOffset? completedAt)
    {
        return new ExportJob { Id = id, Type = type, Format = format, RequestedBy = requestedBy, Status = status, RequestedAt = requestedAt, CompletedAt = completedAt };
    }

    private static ApprovalRequest Approval(string id, string subject, string category, string requestedBy, string status, DateTimeOffset requestedAt)
    {
        return new ApprovalRequest { Id = id, Subject = subject, Category = category, RequestedBy = requestedBy, Status = status, RequestedAt = requestedAt };
    }

    private static NotificationItem Notification(string id, string recipient, string title, string body, string category, bool read, DateTimeOffset createdAt)
    {
        return new NotificationItem { Id = id, Recipient = recipient, Title = title, Body = body, Category = category, Read = read, CreatedAt = createdAt };
    }

    private static PolicyRule Rule(string id, string name, string scope, string field, string op, string value, string outcome, bool enabled)
    {
        return new PolicyRule { Id = id, Name = name, Scope = scope, Field = field, Operator = op, Value = value, Outcome = outcome, Enabled = enabled };
    }

    private static DocumentRecord Document(string id, string title, string owner, string classification, string status, DateTimeOffset updatedAt, string[] tags)
    {
        return new DocumentRecord { Id = id, Title = title, Owner = owner, Classification = classification, Status = status, UpdatedAt = updatedAt, Tags = tags };
    }

    private static CaseRecord Clone(CaseRecord item)
    {
        return new CaseRecord
        {
            Id = item.Id,
            Customer = item.Customer,
            Signal = item.Signal,
            Queue = item.Queue,
            Status = item.Status,
            Owner = item.Owner,
            Priority = item.Priority,
            Region = item.Region,
            Amount = item.Amount,
            CreatedAt = item.CreatedAt,
            UpdatedAt = item.UpdatedAt,
            Notes = [.. item.Notes],
            History = [.. item.History],
        };
    }

    private static IntegrationRecord Clone(IntegrationRecord item)
    {
        return new IntegrationRecord
        {
            Id = item.Id,
            Name = item.Name,
            Environment = item.Environment,
            OwnerEmail = item.OwnerEmail,
            Status = item.Status,
            Health = item.Health,
            BaseUrl = item.BaseUrl,
            LastSync = item.LastSync,
            ErrorCount = item.ErrorCount,
            Metadata = new Dictionary<string, string>(item.Metadata, StringComparer.OrdinalIgnoreCase),
        };
    }

    private static ExportJob Clone(ExportJob item)
    {
        return new ExportJob
        {
            Id = item.Id,
            Type = item.Type,
            Format = item.Format,
            RequestedBy = item.RequestedBy,
            Status = item.Status,
            RequestedAt = item.RequestedAt,
            CompletedAt = item.CompletedAt,
            Filters = new Dictionary<string, string>(item.Filters, StringComparer.OrdinalIgnoreCase),
        };
    }

    private static ApprovalRequest Clone(ApprovalRequest item)
    {
        return new ApprovalRequest
        {
            Id = item.Id,
            Subject = item.Subject,
            Category = item.Category,
            RequestedBy = item.RequestedBy,
            Status = item.Status,
            DecisionBy = item.DecisionBy,
            RequestedAt = item.RequestedAt,
            DecidedAt = item.DecidedAt,
            Attributes = new Dictionary<string, string>(item.Attributes, StringComparer.OrdinalIgnoreCase),
        };
    }

    private static NotificationItem Clone(NotificationItem item)
    {
        return new NotificationItem { Id = item.Id, Recipient = item.Recipient, Title = item.Title, Body = item.Body, Category = item.Category, Read = item.Read, CreatedAt = item.CreatedAt };
    }

    private static PolicyRule Clone(PolicyRule item)
    {
        return new PolicyRule { Id = item.Id, Name = item.Name, Scope = item.Scope, Field = item.Field, Operator = item.Operator, Value = item.Value, Outcome = item.Outcome, Enabled = item.Enabled };
    }

    private static DocumentRecord Clone(DocumentRecord item)
    {
        return new DocumentRecord { Id = item.Id, Title = item.Title, Owner = item.Owner, Classification = item.Classification, Status = item.Status, UpdatedAt = item.UpdatedAt, Tags = [.. item.Tags] };
    }

    private static PortalSetting Clone(PortalSetting item)
    {
        return new PortalSetting { Key = item.Key, Value = item.Value, Group = item.Group, RequiresAdmin = item.RequiresAdmin, UpdatedAt = item.UpdatedAt };
    }
}
