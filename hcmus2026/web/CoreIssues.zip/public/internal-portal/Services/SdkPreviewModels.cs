using System.Diagnostics;
using System.Text.Json;

namespace Chall.Services;

internal sealed record ConnectorPreviewRequest(
    string ConnectorName,
    string Environment,
    string OwnerEmail,
    JsonElement OpenApi)
{
    private static readonly HashSet<string> AllowedEnvironments = new(StringComparer.OrdinalIgnoreCase)
    {
        "sandbox",
        "staging",
        "production",
    };

    public static ConnectorPreviewRequest FromJson(JsonElement root)
    {
        if (root.ValueKind != JsonValueKind.Object)
        {
            throw new InvalidDataException("request body must be an object");
        }

        var connectorName = ReadString(root, "connectorName") ?? ReadString(root, "name");
        if (string.IsNullOrWhiteSpace(connectorName) || connectorName.Length is < 3 or > 80)
        {
            throw new InvalidDataException("connectorName must be between 3 and 80 characters");
        }

        var environment = ReadString(root, "environment") ?? "sandbox";
        if (!AllowedEnvironments.Contains(environment))
        {
            throw new InvalidDataException("environment must be sandbox, staging, or production");
        }

        var ownerEmail = ReadString(root, "ownerEmail") ?? "integrations@example.test";
        if (ownerEmail.Length > 120 || !ownerEmail.Contains('@', StringComparison.Ordinal))
        {
            throw new InvalidDataException("ownerEmail must be a valid email-like value");
        }

        if (!root.TryGetProperty("openApi", out var openApi) && !root.TryGetProperty("spec", out openApi))
        {
            throw new InvalidDataException("openApi is required");
        }

        ValidateOpenApi(openApi);
        ConnectorPreviewInputPolicy.Validate(root);
        return new ConnectorPreviewRequest(connectorName.Trim(), environment.ToLowerInvariant(), ownerEmail.Trim(), openApi);
    }

    private static string? ReadString(JsonElement root, string propertyName)
    {
        return root.TryGetProperty(propertyName, out var property) && property.ValueKind == JsonValueKind.String
            ? property.GetString()
            : null;
    }

    private static void ValidateOpenApi(JsonElement openApi)
    {
        if (openApi.ValueKind != JsonValueKind.Object)
        {
            throw new InvalidDataException("openApi must be an object");
        }

        if (!openApi.TryGetProperty("openapi", out var version) || version.ValueKind != JsonValueKind.String)
        {
            throw new InvalidDataException("openApi.openapi is required");
        }

        if (!openApi.TryGetProperty("info", out var info) || info.ValueKind != JsonValueKind.Object)
        {
            throw new InvalidDataException("openApi.info is required");
        }

        if (!openApi.TryGetProperty("paths", out var paths) || paths.ValueKind != JsonValueKind.Object || !paths.EnumerateObject().Any())
        {
            throw new InvalidDataException("openApi.paths must contain at least one operation");
        }
    }
}

internal static class ConnectorPreviewInputPolicy
{
    private static readonly string[] BlockedTerms =
    [
        "System",
        "File",
        "Console",
        "Read",
        "flag",
        "Process",
        "Diagnostics",
        "StartInfo",
        "UseShell",
        "Redirect",
        "StandardOutput",
        "WaitForExit",
        "static",
        "Write",
        "throw",
        "Exception",
        "DllImport",
        "exec",
        "shell",
        "(char)",
        "new string",
    ];

    public static void Validate(JsonElement root) => Walk(root);

    private static void Walk(JsonElement element)
    {
        switch (element.ValueKind)
        {
            case JsonValueKind.Object:
                foreach (var property in element.EnumerateObject())
                {
                    ValidateStringValue(property.Name);
                    if (property.Value.ValueKind == JsonValueKind.String)
                    {
                        ValidateStringValue(property.Value.GetString() ?? string.Empty);
                    }

                    Walk(property.Value);
                }
                break;
            case JsonValueKind.Array:
                foreach (var item in element.EnumerateArray())
                {
                    Walk(item);
                }
                break;
        }
    }

    private static void ValidateStringValue(string value)
    {
        foreach (var term in BlockedTerms)
        {
            if (value.Contains(term, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("preview request contains a blocked token");
            }
        }
    }
}

internal static class GeneratedClientRunner
{
    private static readonly TimeSpan Timeout = TimeSpan.FromSeconds(30);

    public static async Task<RunResult> RunAsync(string workdir, string generatedOutputPath)
    {
        var projectPath = Path.Combine(workdir, "GeneratedClient.csproj");
        var sourcePath = Path.Combine(workdir, "Program.cs");
        var abstractionsPath = Path.Combine(AppContext.BaseDirectory, "Microsoft.Kiota.Abstractions.dll");

        await File.WriteAllTextAsync(projectPath, $$"""
            <Project Sdk="Microsoft.NET.Sdk">
              <PropertyGroup>
                <OutputType>Exe</OutputType>
                <TargetFramework>net10.0</TargetFramework>
                <Nullable>enable</Nullable>
                <ImplicitUsings>enable</ImplicitUsings>
              </PropertyGroup>
              <ItemGroup>
                <Reference Include="Microsoft.Kiota.Abstractions">
                  <HintPath>{{abstractionsPath}}</HintPath>
                </Reference>
              </ItemGroup>
            </Project>
            """);

        await File.WriteAllTextAsync(sourcePath, $$"""
            public static class ConnectorPreviewSmokeTest
            {
                public static void Main()
                {
                    var item = new {{ClientGenerator.HarnessModel}}();
                    System.Console.WriteLine($"preview default sku: {item.Sku}");
                    System.Console.WriteLine("connector SDK preview smoke test passed");
                }
            }
            """);

        using var process = new Process();
        process.StartInfo.FileName = "dotnet";
        process.StartInfo.ArgumentList.Add("run");
        process.StartInfo.ArgumentList.Add("--project");
        process.StartInfo.ArgumentList.Add(projectPath);
        process.StartInfo.ArgumentList.Add("--no-launch-profile");
        process.StartInfo.RedirectStandardOutput = true;
        process.StartInfo.RedirectStandardError = true;
        process.StartInfo.UseShellExecute = false;
        process.StartInfo.Environment["DOTNET_NOLOGO"] = "1";
        process.StartInfo.Environment["DOTNET_CLI_TELEMETRY_OPTOUT"] = "1";
        process.StartInfo.Environment["DOTNET_SKIP_FIRST_TIME_EXPERIENCE"] = "1";
        process.StartInfo.Environment["KIOTA_GENERATED_OUTPUT"] = generatedOutputPath;

        process.Start();
        var stdoutTask = process.StandardOutput.ReadToEndAsync();
        var stderrTask = process.StandardError.ReadToEndAsync();

        var timedOut = false;
        using var timeout = new CancellationTokenSource(Timeout);
        try
        {
            await process.WaitForExitAsync(timeout.Token);
        }
        catch (OperationCanceledException)
        {
            timedOut = true;
            try
            {
                process.Kill(entireProcessTree: true);
            }
            catch (InvalidOperationException)
            {
            }
        }

        var stdout = await stdoutTask;
        var stderr = await stderrTask;
        return new RunResult(timedOut ? -1 : process.ExitCode, timedOut, stdout, stderr);
    }
}

internal sealed record RunResult(int Status, bool TimedOut, string Stdout, string Stderr);
