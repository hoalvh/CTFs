using System.Text.Json;
using Kiota.Builder;
using Kiota.Builder.Configuration;
using Microsoft.Extensions.Logging.Abstractions;

namespace Chall.Services;

internal static class ClientGenerator
{
    public const string ClientNamespace = "ApiSdk";
    public const string HarnessModel = "ApiSdk.Models.CatalogItem";

    public static async Task<GeneratedClient> GenerateAsync(JsonElement root, string workdir, CancellationToken cancellationToken)
    {
        var specPath = Path.Combine(workdir, "openapi.json");
        var outputPath = Path.Combine(workdir, "generated");
        Directory.CreateDirectory(outputPath);

        await File.WriteAllTextAsync(specPath, root.GetRawText(), cancellationToken);

        var configuration = new GenerationConfiguration
        {
            Language = GenerationLanguage.CSharp,
            OpenAPIFilePath = specPath,
            OutputPath = outputPath,
            ClientClassName = "ApiClient",
            ClientNamespaceName = ClientNamespace,
            CleanOutput = true,
            NoWorkspace = true,
            Serializers = ["none"],
            Deserializers = ["none"],
        };

        using var httpClient = new HttpClient();
        var builder = new KiotaBuilder(NullLogger<KiotaBuilder>.Instance, configuration, httpClient);
        var generated = await builder.GenerateClientAsync(cancellationToken);
        if (!generated)
        {
            throw new InvalidDataException("SDK generation failed");
        }

        var files = Directory.GetFiles(outputPath, "*.cs", SearchOption.AllDirectories)
            .Order(StringComparer.Ordinal)
            .ToArray();
        if (files.Length == 0)
        {
            throw new InvalidDataException("SDK generation did not produce C# source files");
        }

        return new GeneratedClient(outputPath, files.Select(file => Path.GetRelativePath(outputPath, file)).ToArray());
    }
}

internal sealed record GeneratedClient(string OutputPath, string[] Files);
