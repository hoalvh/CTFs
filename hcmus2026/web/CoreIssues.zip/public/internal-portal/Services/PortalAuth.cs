using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;

namespace Chall.Services;

public static class PortalAuth
{
    public const string CookieName = ".AspNetCore.Portal";
    public const string AuthScheme = "Portal";
    public const string SessionClaimType = "session";

    public static async Task<ClaimsPrincipal> EnsureModeratorSessionAsync(HttpContext context)
    {
        if (context.User.Identity?.IsAuthenticated == true)
        {
            return context.User;
        }

        var principal = CreateModeratorPrincipal();
        await context.SignInAsync(AuthScheme, principal);
        context.User = principal;
        return principal;
    }

    public static string EffectiveRole(ClaimsPrincipal principal)
    {
        return IsAdmin(principal) ? "admin" : "moderator";
    }

    public static bool IsAdmin(ClaimsPrincipal principal)
    {
        if (principal.Identity?.IsAuthenticated != true)
        {
            return false;
        }

        return GetSessionValue(principal, "role") == "admin"
            || GetSessionValue(principal, "admin") == "true"
            || principal.IsInRole("admin");
    }

    public static string? GetSessionValue(ClaimsPrincipal principal, string key)
    {
        string? session = principal.FindFirstValue(SessionClaimType);
        return session == null ? null : GetSessionValue(session, key);
    }

    public static string? GetSessionValue(string session, string key)
    {
        foreach (string part in session.Split(';', StringSplitOptions.RemoveEmptyEntries))
        {
            int separator = part.IndexOf('=');
            if (separator > 0 && part[..separator] == key)
            {
                return part[(separator + 1)..];
            }
        }

        return null;
    }

    private static ClaimsPrincipal CreateModeratorPrincipal()
    {
        ClaimsIdentity identity = new(AuthScheme, ClaimTypes.Name, ClaimTypes.Role);
        identity.AddClaim(new Claim(ClaimTypes.Name, "admin"));
        identity.AddClaim(new Claim(ClaimTypes.Role, "moderator"));
        identity.AddClaim(new Claim(SessionClaimType, CreateModeratorSession()));
        return new ClaimsPrincipal(identity);
    }

    private static string CreateModeratorSession()
    {
        return "name=moderator-team-01;admin=false;role=moderator";
    }

}
