using System.Security.Claims;
using Chall.Models;

namespace Chall.Services;

public sealed class AuditTrailService
{
    private readonly PortalDataStore _store;

    public AuditTrailService(PortalDataStore store)
    {
        _store = store;
    }

    public void Record(ClaimsPrincipal principal, string action, string resource, string detail, string severity = "info")
    {
        _store.AddAudit(new AuditEvent(NewId("au"), Actor(principal), action, resource, detail, severity, DateTimeOffset.UtcNow));
    }

    public IReadOnlyList<AuditEvent> Query(string? resource, string? severity, int take)
    {
        var query = _store.Audit().AsEnumerable();
        if (!string.IsNullOrWhiteSpace(resource))
        {
            query = query.Where(item => item.Resource.Contains(resource, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(severity))
        {
            query = query.Where(item => item.Severity.Equals(severity, StringComparison.OrdinalIgnoreCase));
        }

        return query.Take(Math.Clamp(take, 1, 200)).ToList();
    }

    public static string Actor(ClaimsPrincipal principal)
    {
        return principal.FindFirstValue(ClaimTypes.Name) ?? "unknown";
    }

    public static string NewId(string prefix)
    {
        return $"{prefix}_{Guid.NewGuid():N}"[..15];
    }
}

public sealed class CaseWorkflowService
{
    private static readonly Dictionary<string, string[]> Transitions = new(StringComparer.OrdinalIgnoreCase)
    {
        ["waiting"] = ["triage", "escalated", "closed"],
        ["triage"] = ["ready", "waiting", "escalated", "closed"],
        ["ready"] = ["closed", "triage", "escalated"],
        ["escalated"] = ["waiting", "closed"],
        ["closed"] = ["triage"],
    };

    private readonly PortalDataStore _store;
    private readonly AuditTrailService _audit;
    private readonly NotificationCenterService _notifications;

    public CaseWorkflowService(PortalDataStore store, AuditTrailService audit, NotificationCenterService notifications)
    {
        _store = store;
        _audit = audit;
        _notifications = notifications;
    }

    public IReadOnlyList<CaseRecord> List(string? status, string? owner, string? queue)
    {
        var query = _store.Cases().AsEnumerable();
        if (!string.IsNullOrWhiteSpace(status))
        {
            query = query.Where(item => item.Status.Equals(status, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(owner))
        {
            query = query.Where(item => item.Owner.Equals(owner, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(queue))
        {
            query = query.Where(item => item.Queue.Contains(queue, StringComparison.OrdinalIgnoreCase));
        }

        return query.OrderByDescending(item => PriorityRank(item.Priority)).ThenBy(item => item.CreatedAt).ToList();
    }

    public CaseRecord? Get(string id)
    {
        return _store.Case(id);
    }

    public CaseRecord? Assign(string id, AssignCaseRequest request, ClaimsPrincipal principal)
    {
        if (string.IsNullOrWhiteSpace(request.Owner) || request.Owner.Length > 80)
        {
            return null;
        }

        var actor = AuditTrailService.Actor(principal);
        var updated = _store.UpdateCase(id, item =>
        {
            var oldOwner = item.Owner;
            item.Owner = request.Owner.Trim();
            item.History.Add(new CaseEvent("assigned", actor, $"{oldOwner} -> {item.Owner}", DateTimeOffset.UtcNow));
            return true;
        });

        if (updated != null)
        {
            _audit.Record(principal, "case.assign", id, request.Reason ?? $"Assigned to {request.Owner}");
            _notifications.Send(request.Owner, "Case assigned", $"{id} was assigned to you.", "case");
        }

        return updated;
    }

    public CaseRecord? AddNote(string id, CaseNoteRequest request, ClaimsPrincipal principal)
    {
        if (string.IsNullOrWhiteSpace(request.Text) || request.Text.Length > 1000)
        {
            return null;
        }

        var actor = AuditTrailService.Actor(principal);
        var updated = _store.UpdateCase(id, item =>
        {
            item.Notes.Add(new CaseNote(AuditTrailService.NewId("note"), actor, request.Text.Trim(), request.Internal, DateTimeOffset.UtcNow));
            item.History.Add(new CaseEvent("note", actor, request.Internal ? "Internal note added" : "Public note added", DateTimeOffset.UtcNow));
            return true;
        });

        if (updated != null)
        {
            _audit.Record(principal, "case.note", id, request.Internal ? "Internal note added" : "Note added");
        }

        return updated;
    }

    public CaseRecord? Transition(string id, TransitionCaseRequest request, ClaimsPrincipal principal)
    {
        if (string.IsNullOrWhiteSpace(request.Status))
        {
            return null;
        }

        var actor = AuditTrailService.Actor(principal);
        var updated = _store.UpdateCase(id, item =>
        {
            if (!Transitions.TryGetValue(item.Status, out var allowed) || !allowed.Contains(request.Status, StringComparer.OrdinalIgnoreCase))
            {
                return false;
            }

            var oldStatus = item.Status;
            item.Status = request.Status.Trim().ToLowerInvariant();
            item.History.Add(new CaseEvent("transition", actor, $"{oldStatus} -> {item.Status}", DateTimeOffset.UtcNow));
            return true;
        });

        if (updated != null)
        {
            _audit.Record(principal, "case.transition", id, request.Reason ?? $"Moved to {request.Status}");
            if (updated.Status == "escalated")
            {
                _notifications.Send("trust.ops", "Case escalated", $"{id} requires review.", "case");
            }
        }

        return updated;
    }

    private static int PriorityRank(string priority)
    {
        return priority.ToLowerInvariant() switch
        {
            "critical" => 0,
            "high" => 1,
            "medium" => 2,
            _ => 3,
        };
    }
}

public sealed class IntegrationRegistryService
{
    private readonly PortalDataStore _store;
    private readonly AuditTrailService _audit;
    private readonly NotificationCenterService _notifications;

    public IntegrationRegistryService(PortalDataStore store, AuditTrailService audit, NotificationCenterService notifications)
    {
        _store = store;
        _audit = audit;
        _notifications = notifications;
    }

    public IReadOnlyList<IntegrationRecord> List(string? environment, string? health)
    {
        var query = _store.Integrations().AsEnumerable();
        if (!string.IsNullOrWhiteSpace(environment))
        {
            query = query.Where(item => item.Environment.Equals(environment, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(health))
        {
            query = query.Where(item => item.Health.Equals(health, StringComparison.OrdinalIgnoreCase));
        }

        return query.OrderBy(item => item.Name).ToList();
    }

    public IntegrationRecord? Get(string id)
    {
        return _store.Integration(id);
    }

    public IntegrationRecord? Sync(string id, ClaimsPrincipal principal)
    {
        var updated = _store.UpdateIntegration(id, item =>
        {
            item.LastSync = DateTimeOffset.UtcNow;
            item.Status = item.ErrorCount > 2 ? "degraded" : "healthy";
            item.Metadata["lastManualSyncBy"] = AuditTrailService.Actor(principal);
            return true;
        });

        if (updated != null)
        {
            _audit.Record(principal, "integration.sync", id, $"Manual sync for {updated.Name}");
        }

        return updated;
    }

    public IntegrationRecord? UpdateOwner(string id, IntegrationOwnerRequest request, ClaimsPrincipal principal)
    {
        if (string.IsNullOrWhiteSpace(request.OwnerEmail) || !request.OwnerEmail.Contains('@', StringComparison.Ordinal) || request.OwnerEmail.Length > 120)
        {
            return null;
        }

        var updated = _store.UpdateIntegration(id, item =>
        {
            item.OwnerEmail = request.OwnerEmail.Trim();
            item.Metadata["ownerUpdatedAt"] = DateTimeOffset.UtcNow.ToString("O");
            return true;
        });

        if (updated != null)
        {
            _audit.Record(principal, "integration.owner", id, $"Owner changed to {updated.OwnerEmail}");
        }

        return updated;
    }

    public object RegisterWebhook(string id, WebhookEventRequest request, ClaimsPrincipal principal)
    {
        var fingerprint = BuildFingerprint(id, request.EventType, request.ExternalId);
        var updated = _store.UpdateIntegration(id, item =>
        {
            item.LastSync = DateTimeOffset.UtcNow;
            item.Metadata["lastWebhook"] = fingerprint;
            if (request.EventType.Contains("fail", StringComparison.OrdinalIgnoreCase))
            {
                item.ErrorCount++;
                item.Health = "amber";
                item.Status = "degraded";
            }

            return true;
        });

        if (updated == null)
        {
            return new { accepted = false, reason = "unknown connector" };
        }

        _audit.Record(principal, "integration.webhook", id, $"{request.EventType}:{request.ExternalId}");
        if (updated.Health == "amber")
        {
            _notifications.Send(updated.OwnerEmail, "Connector degraded", $"{updated.Name} reported {request.EventType}.", "integration");
        }

        return new { accepted = true, connector = id, fingerprint };
    }

    private static string BuildFingerprint(string connector, string eventType, string externalId)
    {
        var material = $"{connector}:{eventType}:{externalId}".ToLowerInvariant();
        return Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(material)))[..16].ToLowerInvariant();
    }
}

public sealed class ReportExportService
{
    private readonly PortalDataStore _store;
    private readonly AuditTrailService _audit;

    public ReportExportService(PortalDataStore store, AuditTrailService audit)
    {
        _store = store;
        _audit = audit;
    }

    public object Summary()
    {
        var cases = _store.Cases();
        var integrations = _store.Integrations();
        return new
        {
            openCases = cases.Count(item => item.Status != "closed"),
            escalations = cases.Count(item => item.Status == "escalated"),
            queuedReviews = cases.Count,
            degradedConnectors = integrations.Count(item => item.Health is "amber" or "red"),
            lastUpdated = DateTimeOffset.UtcNow.AddMinutes(-7),
        };
    }

    public IReadOnlyList<ExportJob> ListExports(string? status)
    {
        var query = _store.Exports().AsEnumerable();
        if (!string.IsNullOrWhiteSpace(status))
        {
            query = query.Where(item => item.Status.Equals(status, StringComparison.OrdinalIgnoreCase));
        }

        return query.OrderByDescending(item => item.RequestedAt).ToList();
    }

    public ExportJob? GetExport(string id)
    {
        return _store.Export(id);
    }

    public ExportJob CreateExport(ExportJobRequest request, ClaimsPrincipal principal)
    {
        var job = new ExportJob
        {
            Id = AuditTrailService.NewId("ex"),
            Type = string.IsNullOrWhiteSpace(request.Type) ? "operations-rollup" : request.Type.Trim(),
            Format = string.IsNullOrWhiteSpace(request.Format) ? "json" : request.Format.Trim().ToLowerInvariant(),
            RequestedBy = AuditTrailService.Actor(principal),
            Status = "queued",
            RequestedAt = DateTimeOffset.UtcNow,
            Filters = request.Filters == null ? [] : new Dictionary<string, string>(request.Filters, StringComparer.OrdinalIgnoreCase),
        };

        var stored = _store.AddExport(job);
        _audit.Record(principal, "export.create", stored.Id, $"{stored.Type}:{stored.Format}");
        return stored;
    }
}

public sealed class ApprovalWorkflowService
{
    private readonly PortalDataStore _store;
    private readonly AuditTrailService _audit;
    private readonly NotificationCenterService _notifications;

    public ApprovalWorkflowService(PortalDataStore store, AuditTrailService audit, NotificationCenterService notifications)
    {
        _store = store;
        _audit = audit;
        _notifications = notifications;
    }

    public IReadOnlyList<ApprovalRequest> List(string? status)
    {
        var query = _store.Approvals().AsEnumerable();
        if (!string.IsNullOrWhiteSpace(status))
        {
            query = query.Where(item => item.Status.Equals(status, StringComparison.OrdinalIgnoreCase));
        }

        return query.OrderByDescending(item => item.RequestedAt).ToList();
    }

    public ApprovalRequest Submit(ApprovalSubmitRequest request, ClaimsPrincipal principal)
    {
        var approval = new ApprovalRequest
        {
            Id = AuditTrailService.NewId("ap"),
            Subject = string.IsNullOrWhiteSpace(request.Subject) ? "Operational approval" : request.Subject.Trim(),
            Category = string.IsNullOrWhiteSpace(request.Category) ? "general" : request.Category.Trim().ToLowerInvariant(),
            RequestedBy = AuditTrailService.Actor(principal),
            Status = "pending",
            RequestedAt = DateTimeOffset.UtcNow,
            Attributes = request.Attributes == null ? [] : new Dictionary<string, string>(request.Attributes, StringComparer.OrdinalIgnoreCase),
        };

        var stored = _store.AddApproval(approval);
        _notifications.Send("trust.ops", "Approval requested", stored.Subject, "approval");
        _audit.Record(principal, "approval.submit", stored.Id, stored.Subject);
        return stored;
    }

    public ApprovalRequest? Decide(string id, ApprovalDecisionRequest request, ClaimsPrincipal principal)
    {
        var decision = NormalizeDecision(request.Decision);
        if (decision == null)
        {
            return null;
        }

        var actor = AuditTrailService.Actor(principal);
        var updated = _store.UpdateApproval(id, item =>
        {
            if (!item.Status.Equals("pending", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            item.Status = decision;
            item.DecisionBy = actor;
            item.DecidedAt = DateTimeOffset.UtcNow;
            if (!string.IsNullOrWhiteSpace(request.Comment))
            {
                item.Attributes["decisionComment"] = request.Comment.Trim();
            }

            return true;
        });

        if (updated != null)
        {
            _audit.Record(principal, "approval.decide", id, decision);
            _notifications.Send(updated.RequestedBy, "Approval updated", $"{updated.Subject}: {decision}", "approval");
        }

        return updated;
    }

    private static string? NormalizeDecision(string decision)
    {
        if (decision.Equals("approve", StringComparison.OrdinalIgnoreCase) || decision.Equals("approved", StringComparison.OrdinalIgnoreCase))
        {
            return "approved";
        }

        if (decision.Equals("reject", StringComparison.OrdinalIgnoreCase) || decision.Equals("rejected", StringComparison.OrdinalIgnoreCase))
        {
            return "rejected";
        }

        return null;
    }
}

public sealed class NotificationCenterService
{
    private readonly PortalDataStore _store;

    public NotificationCenterService(PortalDataStore store)
    {
        _store = store;
    }

    public IReadOnlyList<NotificationItem> Inbox(ClaimsPrincipal principal, bool unreadOnly)
    {
        var actor = AuditTrailService.Actor(principal);
        var items = _store.Notifications(actor);
        if (unreadOnly)
        {
            items = items.Where(item => !item.Read).ToList();
        }

        return items.OrderByDescending(item => item.CreatedAt).ToList();
    }

    public NotificationItem? MarkRead(string id, ClaimsPrincipal principal)
    {
        var actor = AuditTrailService.Actor(principal);
        return _store.UpdateNotification(id, item =>
        {
            if (!item.Recipient.Equals(actor, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            item.Read = true;
            return true;
        });
    }

    public void Send(string recipient, string title, string body, string category)
    {
        _store.AddNotification(new NotificationItem
        {
            Id = AuditTrailService.NewId("nt"),
            Recipient = recipient,
            Title = title,
            Body = body,
            Category = category,
            Read = false,
            CreatedAt = DateTimeOffset.UtcNow,
        });
    }
}

public sealed class PortalSettingsService
{
    private readonly PortalDataStore _store;
    private readonly AuditTrailService _audit;

    public PortalSettingsService(PortalDataStore store, AuditTrailService audit)
    {
        _store = store;
        _audit = audit;
    }

    public IReadOnlyList<PortalSetting> List(bool includeAdmin)
    {
        return _store.Settings().Where(item => includeAdmin || !item.RequiresAdmin).ToList();
    }

    public PortalSetting? Update(SettingUpdateRequest request, ClaimsPrincipal principal)
    {
        if (!PortalAuth.IsAdmin(principal) && request.RequiresAdmin)
        {
            return null;
        }

        if (string.IsNullOrWhiteSpace(request.Key) || request.Key.Length > 120)
        {
            return null;
        }

        var setting = new PortalSetting
        {
            Key = request.Key.Trim(),
            Value = request.Value?.Trim() ?? "",
            Group = string.IsNullOrWhiteSpace(request.Group) ? "general" : request.Group.Trim(),
            RequiresAdmin = request.RequiresAdmin,
            UpdatedAt = DateTimeOffset.UtcNow,
        };

        var stored = _store.PutSetting(setting);
        _audit.Record(principal, "setting.update", stored.Key, stored.Group);
        return stored;
    }
}

public sealed class RuleEvaluationService
{
    private readonly PortalDataStore _store;

    public RuleEvaluationService(PortalDataStore store)
    {
        _store = store;
    }

    public IReadOnlyList<PolicyRule> List(string? scope)
    {
        var query = _store.Rules().Where(item => item.Enabled);
        if (!string.IsNullOrWhiteSpace(scope))
        {
            query = query.Where(item => item.Scope.Equals(scope, StringComparison.OrdinalIgnoreCase));
        }

        return query.OrderBy(item => item.Scope).ThenBy(item => item.Name).ToList();
    }

    public object Evaluate(RuleEvaluationRequest request)
    {
        var matches = List(request.Scope)
            .Where(rule => request.Facts.TryGetValue(rule.Field, out var value) && Matches(rule, value))
            .Select(rule => new { rule.Id, rule.Name, rule.Outcome })
            .ToList();

        return new
        {
            request.Scope,
            matched = matches.Count,
            matches,
        };
    }

    private static bool Matches(PolicyRule rule, string value)
    {
        return rule.Operator.ToLowerInvariant() switch
        {
            "eq" => value.Equals(rule.Value, StringComparison.OrdinalIgnoreCase),
            "contains" => value.Contains(rule.Value, StringComparison.OrdinalIgnoreCase),
            "gte" => decimal.TryParse(value, out var left) && decimal.TryParse(rule.Value, out var right) && left >= right,
            "lte" => decimal.TryParse(value, out var left) && decimal.TryParse(rule.Value, out var right) && left <= right,
            _ => false,
        };
    }
}

public sealed class WorkbenchSearchService
{
    private readonly PortalDataStore _store;

    public WorkbenchSearchService(PortalDataStore store)
    {
        _store = store;
    }

    public object Search(string query)
    {
        if (string.IsNullOrWhiteSpace(query))
        {
            return new { cases = Array.Empty<CaseRecord>(), integrations = Array.Empty<IntegrationRecord>(), documents = Array.Empty<DocumentRecord>() };
        }

        var term = query.Trim();
        var cases = _store.Cases()
            .Where(item => item.Id.Contains(term, StringComparison.OrdinalIgnoreCase)
                || item.Customer.Contains(term, StringComparison.OrdinalIgnoreCase)
                || item.Signal.Contains(term, StringComparison.OrdinalIgnoreCase))
            .Take(10)
            .ToList();
        var integrations = _store.Integrations()
            .Where(item => item.Name.Contains(term, StringComparison.OrdinalIgnoreCase)
                || item.OwnerEmail.Contains(term, StringComparison.OrdinalIgnoreCase))
            .Take(10)
            .ToList();
        var documents = _store.Documents()
            .Where(item => item.Title.Contains(term, StringComparison.OrdinalIgnoreCase)
                || item.Tags.Any(tag => tag.Contains(term, StringComparison.OrdinalIgnoreCase)))
            .Take(10)
            .ToList();

        return new { cases, integrations, documents };
    }

    public IReadOnlyList<DocumentRecord> Documents(string? classification)
    {
        var query = _store.Documents().AsEnumerable();
        if (!string.IsNullOrWhiteSpace(classification))
        {
            query = query.Where(item => item.Classification.Equals(classification, StringComparison.OrdinalIgnoreCase));
        }

        return query.OrderByDescending(item => item.UpdatedAt).ToList();
    }

    public DocumentRecord Classify(DocumentClassifyRequest request, ClaimsPrincipal principal)
    {
        var classification = request.Tags.Any(tag => tag.Contains("payment", StringComparison.OrdinalIgnoreCase) || tag.Contains("escalation", StringComparison.OrdinalIgnoreCase))
            ? "restricted"
            : "internal";

        return _store.AddDocument(new DocumentRecord
        {
            Id = AuditTrailService.NewId("doc"),
            Title = string.IsNullOrWhiteSpace(request.Title) ? "Untitled document" : request.Title.Trim(),
            Owner = string.IsNullOrWhiteSpace(request.Owner) ? AuditTrailService.Actor(principal) : request.Owner.Trim(),
            Classification = classification,
            Status = "draft",
            UpdatedAt = DateTimeOffset.UtcNow,
            Tags = request.Tags.Select(tag => tag.Trim()).Where(tag => tag.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToArray(),
        });
    }
}
