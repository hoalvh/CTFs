using Microsoft.AspNetCore.Mvc;
using Chall.Models;
using Chall.Services;

namespace Chall.Controllers;

[ApiController]
[Route("api/integrations")]
public sealed class IntegrationsApiController : ControllerBase
{
    private readonly IntegrationRegistryService _integrations;

    public IntegrationsApiController(IntegrationRegistryService integrations)
    {
        _integrations = integrations;
    }

    [HttpGet]
    public IActionResult List([FromQuery] string? environment, [FromQuery] string? health)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_integrations.List(environment, health));
    }

    [HttpGet("{id}")]
    public IActionResult Get(string id)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return _integrations.Get(id) is { } found ? new JsonResult(found) : NotFound(new { error = "connector not found" });
    }

    [HttpPost("{id}/sync")]
    public IActionResult Sync(string id)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return _integrations.Sync(id, User) is { } updated ? new JsonResult(updated) : NotFound(new { error = "connector not found" });
    }

    [HttpPatch("{id}/owner")]
    public IActionResult UpdateOwner(string id, [FromBody] IntegrationOwnerRequest request)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return _integrations.UpdateOwner(id, request, User) is { } updated
            ? new JsonResult(updated)
            : BadRequest(new { error = "owner change was not accepted" });
    }

    [HttpPost("{id}/events")]
    public IActionResult Webhook(string id, [FromBody] WebhookEventRequest request)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_integrations.RegisterWebhook(id, request, User));
    }
}
