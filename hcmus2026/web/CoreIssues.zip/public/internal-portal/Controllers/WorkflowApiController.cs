using Microsoft.AspNetCore.Mvc;
using Chall.Models;
using Chall.Services;

namespace Chall.Controllers;

[ApiController]
[Route("api")]
public sealed class WorkflowApiController : ControllerBase
{
    private readonly ReportExportService _exports;
    private readonly ApprovalWorkflowService _approvals;
    private readonly NotificationCenterService _notifications;
    private readonly WorkbenchSearchService _search;
    private readonly RuleEvaluationService _rules;

    public WorkflowApiController(
        ReportExportService exports,
        ApprovalWorkflowService approvals,
        NotificationCenterService notifications,
        WorkbenchSearchService search,
        RuleEvaluationService rules)
    {
        _exports = exports;
        _approvals = approvals;
        _notifications = notifications;
        _search = search;
        _rules = rules;
    }

    [HttpGet("exports")]
    public IActionResult Exports([FromQuery] string? status)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_exports.ListExports(status));
    }

    [HttpPost("exports")]
    public IActionResult CreateExport([FromBody] ExportJobRequest request)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_exports.CreateExport(request, User));
    }

    [HttpGet("exports/{id}")]
    public IActionResult GetExport(string id)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return _exports.GetExport(id) is { } found ? new JsonResult(found) : NotFound(new { error = "export not found" });
    }

    [HttpGet("approvals")]
    public IActionResult Approvals([FromQuery] string? status)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_approvals.List(status));
    }

    [HttpPost("approvals")]
    public IActionResult SubmitApproval([FromBody] ApprovalSubmitRequest request)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_approvals.Submit(request, User));
    }

    [HttpGet("notifications")]
    public IActionResult Notifications([FromQuery] bool unreadOnly = false)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_notifications.Inbox(User, unreadOnly));
    }

    [HttpPost("notifications/{id}/read")]
    public IActionResult MarkRead(string id)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return _notifications.MarkRead(id, User) is { } item ? new JsonResult(item) : NotFound(new { error = "notification not found" });
    }

    [HttpGet("workbench/search")]
    public IActionResult Search([FromQuery] string q)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_search.Search(q));
    }

    [HttpGet("documents")]
    public IActionResult Documents([FromQuery] string? classification)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_search.Documents(classification));
    }

    [HttpPost("documents/classify")]
    public IActionResult Classify([FromBody] DocumentClassifyRequest request)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_search.Classify(request, User));
    }

    [HttpGet("rules")]
    public IActionResult Rules([FromQuery] string? scope)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_rules.List(scope));
    }

    [HttpPost("rules/evaluate")]
    public IActionResult Evaluate([FromBody] RuleEvaluationRequest request)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_rules.Evaluate(request));
    }
}
