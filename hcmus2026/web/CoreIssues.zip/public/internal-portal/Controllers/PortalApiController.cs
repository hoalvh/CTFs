using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Chall.Services;

namespace Chall.Controllers;

[ApiController]
[Route("api")]
public sealed class PortalApiController : ControllerBase
{
    private readonly ReportExportService _reports;

    public PortalApiController(ReportExportService reports)
    {
        _reports = reports;
    }

    [HttpGet("me")]
    public IActionResult Me()
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(new
        {
            name = User.FindFirstValue(ClaimTypes.Name) ?? "unknown",
            role = PortalAuth.EffectiveRole(User),
            department = User.FindFirstValue("department") ?? "Operations",
        });
    }

    [HttpGet("reports/summary")]
    public IActionResult ReportsSummary()
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_reports.Summary());
    }
}
