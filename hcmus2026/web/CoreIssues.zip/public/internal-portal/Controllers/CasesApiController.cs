using Microsoft.AspNetCore.Mvc;
using Chall.Models;
using Chall.Services;

namespace Chall.Controllers;

[ApiController]
[Route("api/cases")]
public sealed class CasesApiController : ControllerBase
{
    private readonly CaseWorkflowService _cases;

    public CasesApiController(CaseWorkflowService cases)
    {
        _cases = cases;
    }

    [HttpGet]
    public IActionResult List([FromQuery] string? status, [FromQuery] string? owner, [FromQuery] string? queue)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_cases.List(status, owner, queue));
    }

    [HttpGet("{id}")]
    public IActionResult Get(string id)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return _cases.Get(id) is { } found ? new JsonResult(found) : NotFound(new { error = "case not found" });
    }

    [HttpPost("{id}/assign")]
    public IActionResult Assign(string id, [FromBody] AssignCaseRequest request)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return _cases.Assign(id, request, User) is { } updated
            ? new JsonResult(updated)
            : BadRequest(new { error = "assignment was not accepted" });
    }

    [HttpPost("{id}/notes")]
    public IActionResult AddNote(string id, [FromBody] CaseNoteRequest request)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return _cases.AddNote(id, request, User) is { } updated
            ? new JsonResult(updated)
            : BadRequest(new { error = "note was not accepted" });
    }

    [HttpPost("{id}/transition")]
    public IActionResult Transition(string id, [FromBody] TransitionCaseRequest request)
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return _cases.Transition(id, request, User) is { } updated
            ? new JsonResult(updated)
            : BadRequest(new { error = "transition was not accepted" });
    }
}
