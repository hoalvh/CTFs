using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Chall.Services;

namespace Chall.Controllers;

[Route("")]
public sealed class PortalController : Controller
{
    [HttpGet("")]
    public async Task<IActionResult> DashboardAsync()
    {
        await PrepareAsync("Dashboard", "dashboard");
        ViewData["Role"] = "admin";
        return View("Dashboard");
    }

    [HttpGet("profile")]
    public async Task<IActionResult> ProfileAsync()
    {
        var principal = await PrepareAsync("Profile", "profile");
        ViewData["Name"] = principal.FindFirstValue(ClaimTypes.Name) ?? "unknown";
        ViewData["Email"] = principal.FindFirstValue(ClaimTypes.Email) ?? "unknown";
        ViewData["Department"] = principal.FindFirstValue("department") ?? "Operations";
        ViewData["Role"] = "admin";
        return View("Profile");
    }

    [HttpGet("cases")]
    public async Task<IActionResult> CasesAsync()
    {
        await PrepareAsync("Review Queue", "cases");
        return View("Cases");
    }

    [HttpGet("reports")]
    public async Task<IActionResult> ReportsAsync()
    {
        await PrepareAsync("Reports", "reports");
        return View("Reports");
    }

    [HttpGet("integrations")]
    public async Task<IActionResult> IntegrationsAsync()
    {
        await PrepareAsync("Integrations", "integrations");
        return View("Integrations");
    }

    [HttpGet("admin")]
    public async Task<IActionResult> AdminAsync()
    {
        var principal = await PrepareAsync("Administration", "admin");
        return PortalAuth.IsAdmin(principal) ? View("Admin") : View("Restricted");
    }

    [HttpGet("admin/sdk")]
    public async Task<IActionResult> SdkAsync()
    {
        var principal = await PrepareAsync("SDK Preview", "admin");
        return PortalAuth.IsAdmin(principal) ? View("Sdk") : View("Restricted");
    }

    private async Task<ClaimsPrincipal> PrepareAsync(string title, string active)
    {
        var principal = await PortalAuth.EnsureModeratorSessionAsync(HttpContext);
        ViewData["Title"] = title;
        ViewData["Active"] = active;
        ViewData["Principal"] = principal;
        return principal;
    }
}
