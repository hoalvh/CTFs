using Microsoft.AspNetCore.Mvc;
using Chall.Models;
using Chall.Services;

namespace Chall.Controllers;

[ApiController]
[Route("api/admin")]
public sealed class ManagementApiController : ControllerBase
{
    private readonly PortalSettingsService _settings;
    private readonly ApprovalWorkflowService _approvals;
    private readonly AuditTrailService _audit;

    public ManagementApiController(PortalSettingsService settings, ApprovalWorkflowService approvals, AuditTrailService audit)
    {
        _settings = settings;
        _approvals = approvals;
        _audit = audit;
    }

    [HttpGet("settings")]
    public IActionResult Settings()
    {
        if (User.Identity?.IsAuthenticated != true)
        {
            return Unauthorized(new { error = "not authenticated" });
        }

        return new JsonResult(_settings.List(PortalAuth.IsAdmin(User)));
    }

    [HttpPost("settings")]
    public IActionResult UpdateSetting([FromBody] SettingUpdateRequest request)
    {
        if (!PortalAuth.IsAdmin(User))
        {
            return StatusCode(StatusCodes.Status403Forbidden, new { error = "admin access required" });
        }

        return _settings.Update(request, User) is { } updated
            ? new JsonResult(updated)
            : BadRequest(new { error = "setting was not accepted" });
    }

    [HttpPost("approvals/{id}/decision")]
    public IActionResult DecideApproval(string id, [FromBody] ApprovalDecisionRequest request)
    {
        if (!PortalAuth.IsAdmin(User))
        {
            return StatusCode(StatusCodes.Status403Forbidden, new { error = "admin access required" });
        }

        return _approvals.Decide(id, request, User) is { } updated
            ? new JsonResult(updated)
            : BadRequest(new { error = "approval decision was not accepted" });
    }

    [HttpGet("audit")]
    public IActionResult Audit([FromQuery] string? resource, [FromQuery] string? severity, [FromQuery] int take = 100)
    {
        if (!PortalAuth.IsAdmin(User))
        {
            return StatusCode(StatusCodes.Status403Forbidden, new { error = "admin access required" });
        }

        return new JsonResult(_audit.Query(resource, severity, take));
    }
}
