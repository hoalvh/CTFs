using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Chall.Services;

namespace Chall.Controllers;

[ApiController]
[Route("api")]
public sealed class SdkPreviewController : ControllerBase
{
    [HttpPost("admin/sdk/preview")]
    [HttpPost("connectors/preview")]
    public async Task<IActionResult> PreviewAsync()
    {
        if (!PortalAuth.IsAdmin(User))
        {
            return StatusCode(StatusCodes.Status403Forbidden, new { error = "admin access required" });
        }

        JsonDocument document;
        try
        {
            document = await JsonDocument.ParseAsync(Request.Body, cancellationToken: HttpContext.RequestAborted);
        }
        catch (JsonException)
        {
            return BadRequest(new { error = "request body must be JSON" });
        }

        using (document)
        {
            ConnectorPreviewRequest previewRequest;
            try
            {
                previewRequest = ConnectorPreviewRequest.FromJson(document.RootElement);
            }
            catch (InvalidDataException exception)
            {
                return BadRequest(new { error = exception.Message });
            }

            var previewId = $"sdk_{Guid.NewGuid():N}"[..16];
            var workdir = Path.Combine(Path.GetTempPath(), $"sdk-preview-{previewId}");
            Directory.CreateDirectory(workdir);
            try
            {
                var generated = await ClientGenerator.GenerateAsync(previewRequest.OpenApi, workdir, HttpContext.RequestAborted);
                var run = await GeneratedClientRunner.RunAsync(workdir, generated.OutputPath);
                return new JsonResult(new
                {
                    previewId,
                    state = run.Status == 0 && !run.TimedOut ? "ready" : "failed",
                    connector = new
                    {
                        previewRequest.ConnectorName,
                        previewRequest.Environment,
                        previewRequest.OwnerEmail,
                    },
                    sdk = new
                    {
                        generator = "connector-preview",
                        profile = "standard",
                        language = "csharp",
                        @namespace = ClientGenerator.ClientNamespace,
                        files = generated.Files,
                    },
                    smokeTest = new
                    {
                        status = run.Status,
                        timedOut = run.TimedOut,
                        stdout = run.Stdout,
                        stderr = run.Stderr,
                    },
                });
            }
            catch (InvalidDataException exception)
            {
                return BadRequest(new { error = exception.Message });
            }
            finally
            {
                if (Directory.Exists(workdir))
                {
                    Directory.Delete(workdir, recursive: true);
                }
            }
        }
    }
}
