#include <stdio.h>

int main(void) {
    FILE *flag = fopen("/flag.txt", "r");
    int ch;

    if (flag == NULL) {
        return 1;
    }

    while ((ch = fgetc(flag)) != EOF) {
        putchar(ch);
    }

    fclose(flag);
    return 0;
}
