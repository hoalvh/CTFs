namespace Chall.Models;

public sealed class CaseRecord
{
    public string Id { get; set; } = "";
    public string Customer { get; set; } = "";
    public string Signal { get; set; } = "";
    public string Queue { get; set; } = "";
    public string Status { get; set; } = "";
    public string Owner { get; set; } = "";
    public string Priority { get; set; } = "";
    public string Region { get; set; } = "";
    public decimal Amount { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset UpdatedAt { get; set; }
    public List<CaseNote> Notes { get; set; } = [];
    public List<CaseEvent> History { get; set; } = [];
}

public sealed record CaseNote(string Id, string Author, string Text, bool Internal, DateTimeOffset CreatedAt);

public sealed record CaseEvent(string Type, string Actor, string Detail, DateTimeOffset CreatedAt);

public sealed class IntegrationRecord
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Environment { get; set; } = "";
    public string OwnerEmail { get; set; } = "";
    public string Status { get; set; } = "";
    public string Health { get; set; } = "";
    public string BaseUrl { get; set; } = "";
    public DateTimeOffset LastSync { get; set; }
    public int ErrorCount { get; set; }
    public Dictionary<string, string> Metadata { get; set; } = [];
}

public sealed class ExportJob
{
    public string Id { get; set; } = "";
    public string Type { get; set; } = "";
    public string Format { get; set; } = "";
    public string RequestedBy { get; set; } = "";
    public string Status { get; set; } = "";
    public DateTimeOffset RequestedAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public Dictionary<string, string> Filters { get; set; } = [];
}

public sealed class ApprovalRequest
{
    public string Id { get; set; } = "";
    public string Subject { get; set; } = "";
    public string Category { get; set; } = "";
    public string RequestedBy { get; set; } = "";
    public string Status { get; set; } = "";
    public string? DecisionBy { get; set; }
    public DateTimeOffset RequestedAt { get; set; }
    public DateTimeOffset? DecidedAt { get; set; }
    public Dictionary<string, string> Attributes { get; set; } = [];
}

public sealed record AuditEvent(
    string Id,
    string Actor,
    string Action,
    string Resource,
    string Detail,
    string Severity,
    DateTimeOffset CreatedAt);

public sealed class NotificationItem
{
    public string Id { get; set; } = "";
    public string Recipient { get; set; } = "";
    public string Title { get; set; } = "";
    public string Body { get; set; } = "";
    public string Category { get; set; } = "";
    public bool Read { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}

public sealed class PolicyRule
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Scope { get; set; } = "";
    public string Field { get; set; } = "";
    public string Operator { get; set; } = "";
    public string Value { get; set; } = "";
    public string Outcome { get; set; } = "";
    public bool Enabled { get; set; }
}

public sealed class DocumentRecord
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string Owner { get; set; } = "";
    public string Classification { get; set; } = "";
    public string Status { get; set; } = "";
    public DateTimeOffset UpdatedAt { get; set; }
    public string[] Tags { get; set; } = [];
}

public sealed class PortalSetting
{
    public string Key { get; set; } = "";
    public string Value { get; set; } = "";
    public string Group { get; set; } = "";
    public bool RequiresAdmin { get; set; }
    public DateTimeOffset UpdatedAt { get; set; }
}

public sealed record AssignCaseRequest(string Owner, string? Reason);
public sealed record CaseNoteRequest(string Text, bool Internal);
public sealed record TransitionCaseRequest(string Status, string? Reason);
public sealed record ExportJobRequest(string Type, string Format, Dictionary<string, string>? Filters);
public sealed record IntegrationOwnerRequest(string OwnerEmail);
public sealed record WebhookEventRequest(string EventType, string ExternalId, Dictionary<string, string>? Attributes);
public sealed record ApprovalSubmitRequest(string Subject, string Category, Dictionary<string, string>? Attributes);
public sealed record ApprovalDecisionRequest(string Decision, string? Comment);
public sealed record SettingUpdateRequest(string Key, string Value, string Group, bool RequiresAdmin);
public sealed record RuleEvaluationRequest(string Scope, Dictionary<string, string> Facts);
public sealed record DocumentClassifyRequest(string Title, string Owner, string[] Tags);
