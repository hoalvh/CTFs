import json
import ipaddress
import sqlite3
import time
import uuid
from functools import wraps
from pathlib import Path
from urllib.parse import unquote, urljoin, urlparse
import requests
from flask import Flask, flash, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash


app = Flask(__name__)
app.secret_key = uuid.uuid4().hex

STAFF_PORTAL_URL = "http://internal_portal:8080"
DATABASE_PATH = Path("/data/support-gateway.db")
ALLOWED_SEVERITIES = {"low", "medium", "high", "critical"}
BLOCKED_WEBHOOK_HOSTS = ("internal", "portal", "localhost", "metadata")


def get_db():
    if "db" not in g:
        DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
        g.db = sqlite3.connect(DATABASE_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_error):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DATABASE_PATH) as db:
        db.executescript(
            """
            PRAGMA journal_mode = WAL;
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                email TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                public_id TEXT NOT NULL UNIQUE,
                user_id INTEGER NOT NULL,
                customer TEXT NOT NULL,
                topic TEXT NOT NULL,
                severity TEXT NOT NULL,
                message TEXT NOT NULL,
                status TEXT NOT NULL,
                sync_status TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            """
        )


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("user_id") and current_user() is not None:
            return view(*args, **kwargs)

        session.clear()
        if request.path.startswith("/api/"):
            return jsonify({"error": "login required"}), 401

        return redirect(url_for("login", next=request.path))

    return wrapped


def wants_json():
    return request.path.startswith("/api/") or "application/json" in request.headers.get("accept", "")


def current_user():
    if "current_user" not in g:
        user_id = session.get("user_id")
        g.current_user = None
        if user_id:
            g.current_user = get_db().execute(
                "SELECT id, username, email, created_at FROM users WHERE id = ?",
                (user_id,),
            ).fetchone()
    return g.current_user


def normalize_username(username):
    return str(username or "").strip().lower()


def create_user(username, email, password):
    username = normalize_username(username)
    email = str(email or "").strip().lower()
    password = str(password or "")

    if len(username) < 3 or len(username) > 32:
        return None, "Username must be 3 to 32 characters."
    if not all(character.isalnum() or character in {"_", "-", "."} for character in username):
        return None, "Username may contain letters, numbers, dots, dashes, and underscores."
    if "@" not in email or len(email) > 120:
        return None, "A valid email address is required."
    if len(password) < 8:
        return None, "Password must be at least 8 characters."

    try:
        cursor = get_db().execute(
            "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
            (username, email, generate_password_hash(password)),
        )
        get_db().commit()
    except sqlite3.IntegrityError:
        return None, "That username is already registered."

    return cursor.lastrowid, None


def authenticate(username, password):
    user = get_db().execute(
        "SELECT id, username, email, password_hash FROM users WHERE username = ?",
        (normalize_username(username),),
    ).fetchone()
    if user is None or not check_password_hash(user["password_hash"], str(password or "")):
        return None
    return user


def staff_get(path):
    try:
        response = requests.get(f"{STAFF_PORTAL_URL}{path}", timeout=4)
        response.raise_for_status()
        return response.json(), None
    except Exception as exc:
        return None, str(exc)


def parse_headers(value):
    if not value:
        return {}

    if isinstance(value, dict):
        return {str(key): str(item) for key, item in value.items() if str(key).strip()}

    value = str(value).strip()
    if not value:
        return {}

    try:
        decoded = json.loads(value)
        if isinstance(decoded, dict):
            return {str(key): str(item) for key, item in decoded.items() if str(key).strip()}
    except json.JSONDecodeError:
        pass

    headers = {}
    for line in value.splitlines():
        if ":" not in line:
            continue
        key, item = line.split(":", 1)
        key = key.strip()
        if key:
            headers[key] = item.strip()
    return headers


def normalize_webhook_request():
    if request.is_json:
        request_data = request.get_json(silent=True) or {}
    else:
        request_data = request.form.to_dict()

    headers = parse_headers(request_data.get("headers"))
    body = request_data.get("body", "")
    if isinstance(body, (dict, list)):
        body = json.dumps(body)
        headers.setdefault("Content-Type", "application/json")

    return {
        "url": str(request_data.get("url", "")).strip(),
        "method": str(request_data.get("method", "GET")).upper().strip(),
        "headers": headers,
        "body": body if body is not None else "",
        "timeout": request_data.get("timeout", 5),
    }


def webhook_host_for_policy(parsed):
    netloc = parsed.netloc.rsplit("@", 1)[-1]
    if netloc.startswith("["):
        return netloc[1:].split("]", 1)[0]
    return netloc.rsplit(":", 1)[0].strip(".")


def validate_webhook_target(target, redirected=False):
    parsed = urlparse(target)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None, {"ok": False, "error": "webhook URL must be absolute HTTP or HTTPS"}, 400
    if parsed.username or parsed.password:
        return None, {"ok": False, "error": "webhook URL userinfo is not supported"}, 400

    hostname = webhook_host_for_policy(parsed)
    if not hostname or any(character.isspace() for character in hostname):
        return None, {"ok": False, "error": "webhook URL host is invalid"}, 400

    checked = hostname.casefold()
    decoded_checked = unquote(hostname).casefold()
    if any(blocked in checked or blocked in decoded_checked for blocked in BLOCKED_WEBHOOK_HOSTS):
        return None, {"ok": False, "error": "webhook URL host is not allowed"}, 403
    if not redirected and "." not in hostname:
        return None, {"ok": False, "error": "webhook URL host is not allowed"}, 403

    try:
        address = ipaddress.ip_address(hostname.strip("[]"))
        if address.is_private or address.is_loopback or address.is_link_local or address.is_reserved:
            return None, {"ok": False, "error": "webhook URL host is not allowed"}, 403
    except ValueError:
        pass

    return parsed, None, None


def webhook_connect_url(parsed):
    hostname = unquote(parsed.hostname or "")
    try:
        hostname = hostname.lower().encode("idna").decode("ascii")
    except UnicodeError:
        hostname = hostname.lower()

    netloc = hostname
    if parsed.port is not None:
        netloc = f"{netloc}:{parsed.port}"

    return parsed._replace(netloc=netloc).geturl()


def perform_webhook_fetch(request_data):
    target = request_data["url"]
    method = request_data["method"]
    if method not in {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"}:
        return {"ok": False, "error": "method is not supported"}, 400

    try:
        timeout = min(max(float(request_data["timeout"]), 1), 90)
    except (TypeError, ValueError):
        timeout = 5

    started = time.perf_counter()
    headers = request_data["headers"]
    body = request_data["body"].encode() if isinstance(request_data["body"], str) else request_data["body"]
    redirect_count = 0
    client = requests.Session()

    try:
        while True:
            parsed, error, error_status = validate_webhook_target(target, redirect_count > 0)
            if error is not None:
                return error, error_status

            response = requests.request(
                method,
                webhook_connect_url(parsed),
                headers=headers,
                data=body,
                timeout=timeout,
                allow_redirects=False,
            )

            location = response.headers.get("Location")
            if response.is_redirect and location and redirect_count < 5:
                target = urljoin(target, location)
                next_request = requests.Request(method, target, headers=headers, data=body)
                prepared_next = client.prepare_request(next_request)
                client.rebuild_method(prepared_next, response)
                if prepared_next.method != method:
                    method = prepared_next.method
                    body = None
                redirect_count += 1
                continue

            break
    except requests.RequestException as exc:
        return {
            "ok": False,
            "requestId": short_id("wh"),
            "error": str(exc),
            "elapsedMs": int((time.perf_counter() - started) * 1000),
        }, 502

    content = response.text
    limit = 65536
    return {
        "ok": True,
        "requestId": short_id("wh"),
        "status": response.status_code,
        "elapsedMs": int((time.perf_counter() - started) * 1000),
        "headers": dict(response.headers),
        "body": content[:limit],
        "truncated": len(content) > limit,
    }, 200


def short_id(prefix):
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


def ticket_rows(user_id=None, limit=50):
    if user_id is None:
        return get_db().execute(
            """
            SELECT tickets.*, users.username AS created_by
            FROM tickets JOIN users ON tickets.user_id = users.id
            ORDER BY tickets.id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    return get_db().execute(
        """
        SELECT tickets.*, users.username AS created_by
        FROM tickets JOIN users ON tickets.user_id = users.id
        WHERE tickets.user_id = ?
        ORDER BY tickets.id DESC
        LIMIT ?
        """,
        (user_id, limit),
    ).fetchall()


def create_ticket(user_id, ticket_data):
    severity = str(ticket_data.get("severity", "medium")).strip().lower()
    if severity not in ALLOWED_SEVERITIES:
        severity = "medium"

    ticket = {
        "public_id": short_id("SUP").upper(),
        "customer": str(ticket_data.get("customer", "")).strip()[:120] or "Unknown customer",
        "topic": str(ticket_data.get("topic", "")).strip()[:160] or "Support request",
        "severity": severity,
        "message": str(ticket_data.get("message", "")).strip()[:2000],
        "status": "open",
        "sync_status": "queued",
    }
    ticket["sync_status"] = sync_ticket(ticket)

    get_db().execute(
        """
        INSERT INTO tickets (public_id, user_id, customer, topic, severity, message, status, sync_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            ticket["public_id"],
            user_id,
            ticket["customer"],
            ticket["topic"],
            ticket["severity"],
            ticket["message"],
            ticket["status"],
            ticket["sync_status"],
        ),
    )
    get_db().commit()
    return get_db().execute(
        """
        SELECT tickets.*, users.username AS created_by
        FROM tickets JOIN users ON tickets.user_id = users.id
        WHERE public_id = ?
        """,
        (ticket["public_id"],),
    ).fetchone()


def sync_ticket(ticket):
    note = {
        "text": f"{ticket['public_id']} {ticket['customer']}: {ticket['topic']} ({ticket['severity']})",
        "internal": True,
    }
    try:
        response = requests.post(f"{STAFF_PORTAL_URL}/api/cases/MR-2841/notes", json=note, timeout=4)
        return "accepted" if response.status_code < 500 else "retry"
    except requests.RequestException:
        return "retry"


def row_to_ticket(row):
    return {
        "id": row["public_id"],
        "customer": row["customer"],
        "topic": row["topic"],
        "severity": row["severity"],
        "message": row["message"],
        "status": row["status"],
        "sync": row["sync_status"],
        "createdBy": row["created_by"],
        "createdAt": row["created_at"],
    }


@app.get("/healthz")
def healthz():
    return jsonify({"ok": True, "service": "support-gateway"})


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        request_data = request.get_json(silent=True) if request.is_json else request.form
        user_id, error = create_user(request_data.get("username"), request_data.get("email"), request_data.get("password"))
        if error:
            if wants_json():
                return jsonify({"ok": False, "error": error}), 409 if "already" in error else 400
            flash(error, "error")
            return render_template("signup.html", form=request_data), 400

        session["user_id"] = user_id
        if wants_json():
            return jsonify({"ok": True, "user": normalize_username(request_data.get("username"))}), 201
        return redirect(url_for("dashboard"))

    return render_template("signup.html", form={})


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        request_data = request.get_json(silent=True) if request.is_json else request.form
        user = authenticate(request_data.get("username"), request_data.get("password"))
        if user is not None:
            session["user_id"] = user["id"]
            if wants_json():
                return jsonify({"ok": True, "user": user["username"]})
            return redirect(request.args.get("next") or url_for("dashboard"))

        if wants_json():
            return jsonify({"ok": False, "error": "Invalid username or password"}), 401
        flash("Invalid username or password", "error")

    return render_template("login.html")


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/")
@login_required
def dashboard():
    user = current_user()
    summary, summary_error = staff_get("/api/reports/summary")
    integrations, integrations_error = staff_get("/api/integrations")
    tickets = [row_to_ticket(row) for row in ticket_rows(user["id"], limit=5)]
    return render_template(
        "dashboard.html",
        title="Overview",
        user=user,
        tickets=tickets,
        summary=summary,
        summary_error=summary_error,
        integrations=integrations[:4] if isinstance(integrations, list) else [],
        integrations_error=integrations_error,
    )


@app.route("/tickets", methods=["GET", "POST"])
@login_required
def tickets():
    user = current_user()
    if request.method == "POST":
        ticket = create_ticket(user["id"], request.form)
        flash(f"Created {ticket['public_id']} and queued staff sync.", "success")
        return redirect(url_for("tickets"))

    rows = [row_to_ticket(row) for row in ticket_rows(user["id"])]
    return render_template("tickets.html", title="Tickets", user=user, tickets=rows)


@app.get("/api/session")
@login_required
def api_session():
    user = current_user()
    return jsonify({"user": user["username"], "staffPortal": "available"})


@app.get("/api/tickets")
@login_required
def api_tickets():
    user = current_user()
    return jsonify([row_to_ticket(row) for row in ticket_rows(user["id"])])


@app.post("/api/tickets")
@login_required
def api_create_ticket():
    request_data = request.get_json(silent=True) or {}
    user = current_user()
    return jsonify(row_to_ticket(create_ticket(user["id"], request_data))), 201


@app.post("/api/signup")
def api_signup():
    request_data = request.get_json(silent=True) or {}
    user_id, error = create_user(request_data.get("username"), request_data.get("email"), request_data.get("password"))
    if error:
        return jsonify({"ok": False, "error": error}), 409 if "already" in error else 400
    session["user_id"] = user_id
    return jsonify({"ok": True, "user": normalize_username(request_data.get("username"))}), 201


@app.post("/api/login")
def api_login():
    request_data = request.get_json(silent=True) or {}
    user = authenticate(request_data.get("username"), request_data.get("password"))
    if user is None:
        return jsonify({"ok": False, "error": "Invalid username or password"}), 401
    session["user_id"] = user["id"]
    return jsonify({"ok": True, "user": user["username"]})


# todo: internal feature, for admin only
# todo: keep this out of the UI until get approve.
@app.post("/api/webhooks/test")
def api_webhook_test():
    result, status = perform_webhook_fetch(normalize_webhook_request())
    return jsonify(result), status


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
