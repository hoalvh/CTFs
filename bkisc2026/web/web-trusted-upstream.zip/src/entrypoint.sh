#!/bin/sh
echo "[boot] starting service.py"
python3 /app/service.py &
SERVICE_PID=$!

sleep 1

echo "[boot] starting named"
/usr/local/sbin/named -g -c /etc/named.conf &
NAMED_PID=$!

wait $SERVICE_PID
echo "[boot] service.py exited"
