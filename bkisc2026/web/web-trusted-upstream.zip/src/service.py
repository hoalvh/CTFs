#!/usr/bin/env python3
import base64
import json
import os
import random
import socket
import string
import struct
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DNS_LISTEN_ADDR = "127.0.0.1"
DNS_LISTEN_PORT = 5353
HTTP_LISTEN_PORT = int(os.environ.get("ADMIN_PORT", "8080"))
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("ADMIN_PASS", "admin")
RESOLVER_HOST = "127.0.0.1"
RESOLVER_PORT = 53
NAMED_PID_FILE = "/tmp/named.pid"
FLAG_VALUE = os.environ.get("GZCTF_FLAG", "BKISC{fake_flag_for_testing}")
FAIL_THRESHOLD = 3
MAX_CYCLE_BYTES = 32 * 1024

state_lock = threading.Lock()
state = {
    "cycle": [],
    "cycle_index": 0,
    "resolver_alive": False,
    "fails": 0,
    "was_ever_alive": False,
    "flag_announced": False,
}


def encode_name(name):
    if name == ".":
        return b"\x00"
    out = b""
    for p in name.rstrip(".").split("."):
        b = p.encode("ascii", errors="replace")[:63]
        out += bytes([len(b)]) + b
    return out + b"\x00"


def parse_query(data):
    if len(data) < 12:
        return None
    qid = struct.unpack("!H", data[0:2])[0]
    pos = 12
    while pos < len(data):
        length = data[pos]
        if length == 0:
            pos += 1
            break
        if length >= 192:
            pos += 2
            break
        pos += 1 + length
    if pos + 4 > len(data):
        return None
    return qid, data[12:pos + 4]


def serve_one(sock, data, addr):
    parsed = parse_query(data)
    if parsed is None:
        return
    qid, qsection = parsed
    with state_lock:
        cycle = state["cycle"]
        if cycle:
            i = state["cycle_index"]
            entry = cycle[i % len(cycle)]
            state["cycle_index"] = i + 1
        else:
            entry = None
    if entry is None:
        flags = 0x8480
        resp = struct.pack("!HHHHHH", qid, flags, 1, 0, 0, 0) + qsection
    else:
        an = entry["an"]
        ns = entry["ns"]
        ar = entry["ar"]
        body = b"".join(an) + b"".join(ns) + b"".join(ar)
        header = struct.pack("!HHHHHH", qid, entry["flags"], 1, len(an), len(ns), len(ar))
        resp = header + qsection + body
    try:
        sock.sendto(resp, addr)
    except OSError:
        pass


def dns_server():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((DNS_LISTEN_ADDR, DNS_LISTEN_PORT))
    print(f"[dns] forwarder on {DNS_LISTEN_ADDR}:{DNS_LISTEN_PORT}", flush=True)
    while True:
        try:
            data, addr = s.recvfrom(65535)
            threading.Thread(target=serve_one, args=(s, data, addr), daemon=True).start()
        except Exception as e:
            print(f"[dns] err: {e}", flush=True)


def probe_resolver():
    try:
        with open(NAMED_PID_FILE) as f:
            pid = int(f.read().strip())
        os.kill(pid, 0)
        return True
    except (FileNotFoundError, ValueError, ProcessLookupError, PermissionError):
        return False


def watcher():
    print("[watcher] starting", flush=True)
    while True:
        if probe_resolver():
            with state_lock:
                state["was_ever_alive"] = True
                state["resolver_alive"] = True
                state["fails"] = 0
        else:
            with state_lock:
                if state["was_ever_alive"]:
                    state["fails"] += 1
                    fails = state["fails"]
                    state["resolver_alive"] = False
                    if fails >= FAIL_THRESHOLD and not state["flag_announced"]:
                        state["flag_announced"] = True
                        print(f"[watcher] named gone (fails={fails}); flag enabled", flush=True)
        time.sleep(1)


def random_label(n=8):
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))


QTYPES_DIVERSE = [1, 2, 5, 6, 12, 15, 16, 28, 33, 35, 43, 44, 46, 48, 255]


def trigger_queries(base_qname, qtype, count, randomize):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sent = 0
    base = base_qname.rstrip(".")
    types = QTYPES_DIVERSE if qtype == 0 else [qtype]
    for i in range(count):
        if randomize:
            qname = f"{random_label()}-{i}.{base}."
        else:
            qname = base + "."
        qsec = encode_name(qname) + struct.pack("!HH", types[i % len(types)], 1)
        qid = random.randint(0, 0xFFFF)
        h = struct.pack("!HHHHHH", qid, 0x0100, 1, 0, 0, 0)
        try:
            s.sendto(h + qsec, (RESOLVER_HOST, RESOLVER_PORT))
            sent += 1
        except OSError:
            pass
    s.close()
    return sent


_CSS = """
:root { --bg:#0d1117; --card:#161b22; --border:#30363d; --text:#c9d1d9;
        --muted:#8b949e; --accent:#58a6ff; --green:#56d364;
        --red:#f85149; --yellow:#d29922; }
*  { box-sizing:border-box; }
body { font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
       background:var(--bg); color:var(--text); margin:0; padding:20px; }
a { color:var(--accent); text-decoration:none; }
a:hover { text-decoration:underline; }
.center { max-width:460px; margin:80px auto; padding:40px;
          background:var(--card); border:1px solid var(--border);
          border-radius:12px; text-align:center; }
.wrap { max-width:840px; margin:24px auto; }
h1 { color:var(--accent); font-size:22px; font-weight:500; margin:0 0 6px; }
.sub { color:var(--muted); font-size:13px; margin-bottom:28px; }
.btn { display:inline-block; padding:10px 24px; background:var(--accent);
       color:#fff; border-radius:6px; font-weight:500;
       text-decoration:none; }
.btn:hover { background:#4493f8; text-decoration:none; }
.grid { display:grid; grid-template-columns:repeat(2,1fr); gap:14px; }
.card { background:var(--card); border:1px solid var(--border);
        padding:20px; border-radius:8px; }
.label { color:var(--muted); font-size:11px; letter-spacing:0.06em;
         text-transform:uppercase; margin-bottom:10px; }
.value { font-family:"SF Mono",ui-monospace,monospace; font-size:18px; }
.badge { display:inline-block; padding:4px 10px; border-radius:14px;
         font-size:13px; font-weight:500; }
.badge.ok   { background:rgba(86,211,100,.12); color:var(--green);
              border:1px solid rgba(86,211,100,.35); }
.badge.warn { background:rgba(210,153,34,.12); color:var(--yellow);
              border:1px solid rgba(210,153,34,.35); }
.badge.err  { background:rgba(248,81,73,.12);  color:var(--red);
              border:1px solid rgba(248,81,73,.35); }
.footer { color:var(--muted); font-size:11px; margin-top:24px;
          text-align:center; }
"""

LANDING_HTML = (f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Upstream DNS Console</title>
<style>{_CSS}</style></head>
<body><div class="center">
<h1>Upstream DNS Console</h1>
<p class="sub">Internal infrastructure management.<br>Authorized personnel only.</p>
<a class="btn" href="/dashboard">Sign in</a>
<p class="footer">v0.5 &middot; ops@internal</p>
</div></body></html>
""").encode()


def render_dashboard():
    with state_lock:
        alive = state["resolver_alive"]
        ever = state["was_ever_alive"]
        cl = len(state["cycle"])
        ci = state["cycle_index"]
        fails = state["fails"]
    if not ever:
        hcls, hstate = "warn", "starting up"
    elif alive:
        hcls, hstate = "ok", "operational"
    else:
        hcls, hstate = "err", "offline"
    html = f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="5">
<title>Upstream DNS Console &middot; Dashboard</title>
<style>{_CSS}</style></head>
<body><div class="wrap">
<h1>Upstream DNS Console</h1>
<p class="sub">Operational dashboard &middot; auto-refresh every 5s</p>
<div class="grid">
  <div class="card"><div class="label">Resolver state</div>
    <span class="badge {hcls}">{hstate}</span></div>
  <div class="card"><div class="label">Loaded templates</div>
    <div class="value">{cl}</div></div>
  <div class="card"><div class="label">Replays served</div>
    <div class="value">{ci}</div></div>
  <div class="card"><div class="label">Health probe misses</div>
    <div class="value">{fails}</div></div>
</div>
<p class="footer">upstream-dns v0.5 &middot; signed in as {ADMIN_USER}</p>
</div></body></html>
"""
    return html.encode()


def check_auth(header):
    if not header or not header.startswith("Basic "):
        return False
    try:
        raw = base64.b64decode(header[6:]).decode()
    except Exception:
        return False
    if ":" not in raw:
        return False
    u, p = raw.split(":", 1)
    return u == ADMIN_USER and p == ADMIN_PASS


def parse_cycle(cycle_in):
    parsed = []
    for entry in cycle_in:
        flags_raw = entry.get("flags", "8000")
        flags = int(str(flags_raw).replace(" ", ""), 16) if isinstance(flags_raw, str) else int(flags_raw)
        if not 0 <= flags <= 0xFFFF:
            raise ValueError("flags must fit in 16 bits (0-ffff)")
        an = [bytes.fromhex(rr.replace(" ", "")) for rr in entry.get("an", []) or []]
        ns = [bytes.fromhex(rr.replace(" ", "")) for rr in entry.get("ns", []) or []]
        ar = [bytes.fromhex(rr.replace(" ", "")) for rr in entry.get("ar", []) or []]
        body_len = sum(len(rr) for rr in an + ns + ar)
        if body_len > MAX_CYCLE_BYTES:
            raise ValueError(f"cycle entry body too large ({body_len} > {MAX_CYCLE_BYTES} bytes)")
        parsed.append({"flags": flags, "an": an, "ns": ns, "ar": ar})
    return parsed


class Handler(BaseHTTPRequestHandler):
    server_version = "upstream-dns-admin/0.5"

    def _unauth(self):
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="upstream-dns admin"')
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"401 Unauthorized\n")

    def _json(self, code, obj):
        body = json.dumps(obj).encode() + b"\n"
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        sys.stderr.write("[http] " + fmt % args + "\n")

    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(LANDING_HTML)))
            self.end_headers()
            self.wfile.write(LANDING_HTML)
            return
        if not check_auth(self.headers.get("Authorization")):
            self._unauth()
            return
        if self.path == "/dashboard":
            body = render_dashboard()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path == "/status":
            with state_lock:
                self._json(200, {
                    "cycle_length": len(state["cycle"]),
                    "cycle_index": state["cycle_index"],
                    "resolver_alive": state["resolver_alive"],
                    "fails": state["fails"],
                    "was_ever_alive": state["was_ever_alive"],
                })
            return
        if self.path == "/flag":
            with state_lock:
                alive = state["resolver_alive"]
                fails = state["fails"]
                ever = state["was_ever_alive"]
            if ever and not alive and fails >= FAIL_THRESHOLD:
                body = (FLAG_VALUE + "\n").encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self._json(425, {"error": "downstream resolver still alive"})
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        if not check_auth(self.headers.get("Authorization")):
            self._unauth()
            return
        length = int(self.headers.get("Content-Length") or "0")
        body = self.rfile.read(length) if length else b""
        try:
            obj = json.loads(body or b"{}")
        except Exception:
            self._json(400, {"error": "invalid JSON"})
            return
        if self.path == "/response":
            cycle_in = obj.get("cycle")
            if not isinstance(cycle_in, list) or not cycle_in:
                self._json(400, {"error": "cycle must be a non-empty list"})
                return
            try:
                parsed = parse_cycle(cycle_in)
            except (ValueError, TypeError, AttributeError) as e:
                self._json(400, {"error": f"invalid cycle: {e}"})
                return
            with state_lock:
                state["cycle"] = parsed
                state["cycle_index"] = 0
            print(f"[admin] cycle set: {len(parsed)} entries", flush=True)
            self._json(200, {"cycle_length": len(parsed)})
            return
        if self.path == "/trigger":
            qname = str(obj.get("qname", "")).strip()
            try:
                qtype = int(obj.get("qtype", 1))
                count = int(obj.get("count", 1))
            except (TypeError, ValueError):
                self._json(400, {"error": "qtype and count must be integers"})
                return
            randomize = bool(obj.get("randomize", True))
            if not qname or qname == ".":
                self._json(400, {"error": "qname required"})
                return
            count = max(1, min(count, 5000))
            sent = trigger_queries(qname, qtype, count, randomize)
            self._json(200, {"sent": sent})
            return
        self.send_response(404)
        self.end_headers()


def http_server():
    srv = ThreadingHTTPServer(("0.0.0.0", HTTP_LISTEN_PORT), Handler)
    print(f"[http] admin on 0.0.0.0:{HTTP_LISTEN_PORT} (user={ADMIN_USER})", flush=True)
    srv.serve_forever()


def main():
    threading.Thread(target=dns_server, daemon=True).start()
    threading.Thread(target=watcher, daemon=True).start()
    http_server()


if __name__ == "__main__":
    main()
