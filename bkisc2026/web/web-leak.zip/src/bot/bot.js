const { chromium } = require('playwright');
const express = require('express');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const URL = process.env.URL || 'http://127.0.0.1:3000';
const USERNAME = process.env.USERNAME || 'sliderboo';
const PASSWORD = process.env.PASSWORD || 'password';
const FLAG = process.env.GZCTF_FLAG || 'BKISC{fake_flag}';
let SESSION = '';

let browser;

const initSession = async () => {
    const body = new URLSearchParams({ username: USERNAME, password: PASSWORD });
    const loginUrl = new globalThis.URL('/login', URL);

    const res = await fetch(loginUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body,
        redirect: 'manual',
    });

    const setCookies = res.headers.getSetCookie?.() || [res.headers.get('set-cookie') || ''];
    const match = setCookies.join(';').match(/(?:^|;\s*)session=([^;]+)/);
    if (!match) throw new Error('Could not extract session cookie from /login response');
    SESSION = match[1];
    console.log('Session initialized from /login');
};

(async () => {
    try {
        await initSession();
        browser = await chromium.launch({
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-gpu',
            ]
        });

        app.listen(8000, () => console.log('Bot listening on port 8000'));
    } catch (e) {
        console.error('Bot init failed:', e);
        process.exit(1);
    }
})();

const visit = async (url) => {
    console.log(`Visiting: ${url}`);

    let context = null;
    try {
        if (!browser) return;

        context = await browser.newContext({
            viewport: { width: 800, height: 600 }
        });

        const page = await context.newPage();

        await page.goto(URL);
        await context.addCookies([{
            name: 'session',
            value: SESSION,
            url: URL,
            httpOnly: true
        }]);

        await page.goto(url, { waitUntil: 'load', timeout: 5000 });

        await new Promise(r => setTimeout(r, 1000));

    } catch (e) {
        console.error(e);
    } finally {
        if (context) await context.close();
    }
};

app.get('/visit', async (req, res) => {
    const url = req.query.url;
    if (!url) return res.send('Missing url');

    visit(url);
    res.send('Admin is visiting...');
});
