import os
from flask import (
    Flask,
    flash,
    jsonify,
    redirect,
    render_template,
    render_template_string,
    request,
    session,
    url_for,
)

from database import get_post_db_connection, get_user_db_connection, init_db

app = Flask(__name__)
app.secret_key = os.urandom(64).hex()


def _require_login():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return None


def _get_pinned_post_id(user_id):
    user_conn = get_user_db_connection()
    user_c = user_conn.cursor()
    user_c.execute("SELECT pinned_post_id FROM users WHERE id = ?", (user_id,))
    current_user = user_c.fetchone()
    user_conn.close()

    if current_user and current_user[0] is not None:
        return current_user[0]
    return -1


@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('post_list'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if len(username) > 5:
            flash('Username must be 5 characters or less!')
            return render_template('register.html')

        if len(password) > 5:
            flash('Password must be 5 characters or less!')
            return render_template('register.html')

        conn = get_user_db_connection()
        c = conn.cursor()

        try:
            c.execute(
                "INSERT INTO users (username, password, role) VALUES (?, ?, 'user')",
                (username, password),
            )
            conn.commit()
            flash('Registration successful!')
            return redirect(url_for('login'))
        except Exception:
            flash('Username already exists!')
        finally:
            conn.close()

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_user_db_connection()
        c = conn.cursor()
        c.execute(
            "SELECT id, username, role FROM users WHERE username = ? AND password = ?",
            (username, password),
        )
        user = c.fetchone()
        conn.close()

        if user:
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['role'] = user[2]
            return redirect(url_for('post_list'))

        flash('Invalid credentials!')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/posts')
def post_list():
    login_redirect = _require_login()
    if login_redirect:
        return login_redirect

    user_id = session['user_id']
    post_search = request.args.get('post_search', '')
    pinned_post_id = _get_pinned_post_id(user_id)

    post_conn = get_post_db_connection()
    post_c = post_conn.cursor()
    if post_search:
        post_c.execute(
            "SELECT id, title, content, is_public, user_id FROM posts "
            "WHERE (is_public = 1 OR user_id = ?) "
            "AND ((instr(title, ?) > 0 OR instr(content, ?) > 0) OR id = ?) "
            "ORDER BY CASE WHEN id = ? THEN 0 ELSE 1 END, id DESC",
            (user_id, post_search, post_search, pinned_post_id, pinned_post_id),
        )
    else:
        post_c.execute(
            "SELECT id, title, content, is_public, user_id FROM posts "
            "WHERE is_public = 1 OR user_id = ? "
            "ORDER BY CASE WHEN id = ? THEN 0 ELSE 1 END, id DESC",
            (user_id, pinned_post_id),
        )
    posts = post_c.fetchall()
    post_conn.close()

    user_conn = get_user_db_connection()
    user_c = user_conn.cursor()
    user_c.execute("SELECT username FROM users ORDER BY id ASC")
    users = user_c.fetchall()

    author_names = {}
    post_owner_ids = sorted({post[4] for post in posts})
    if post_owner_ids:
        placeholders = ','.join('?' for _ in post_owner_ids)
        user_c.execute(
            f"SELECT id, username FROM users WHERE id IN ({placeholders})",
            tuple(post_owner_ids),
        )
        author_names = {row[0]: row[1] for row in user_c.fetchall()}

    feed_posts = []
    for post_id, title, content, is_public, owner_id in posts:
        feed_posts.append(
            (
                post_id,
                title,
                content,
                is_public,
                author_names.get(owner_id, 'unknown'),
                post_id == pinned_post_id,
            )
        )
    user_conn.close()

    return render_template(
        'post_list.html',
        posts=feed_posts,
        users=users,
        post_search=post_search,
    )


@app.route('/api/users')
def api_users():
    if 'user_id' not in session:
        return jsonify([]), 401

    conn = get_user_db_connection()
    c = conn.cursor()
    c.execute("SELECT username FROM users ORDER BY id ASC")
    users = c.fetchall()
    conn.close()

    return jsonify([{'name': user[0]} for user in users])


@app.route('/users')
def user_list():
    return redirect(url_for('post_list'))


@app.route('/post/<int:post_id>/pin', methods=['GET'])
def post_pin(post_id):
    login_redirect = _require_login()
    if login_redirect:
        return login_redirect

    user_id = session['user_id']

    post_conn = get_post_db_connection()
    post_c = post_conn.cursor()
    post_c.execute(
        "SELECT id FROM posts WHERE id = ? AND (is_public = 1 OR user_id = ?)",
        (post_id, user_id),
    )
    post = post_c.fetchone()
    post_conn.close()

    if not post:
        flash('Post not found on your feed.')
        return redirect(url_for('post_list'))

    user_conn = get_user_db_connection()
    user_c = user_conn.cursor()
    user_c.execute(
        "UPDATE users SET pinned_post_id = ? WHERE id = ?",
        (post_id, user_id),
    )
    user_conn.commit()
    user_conn.close()

    flash('Post pinned to the top of your feed.')
    return redirect(url_for('post_list', post_search=request.args.get('post_search', '')))


@app.route('/post/unpin', methods=['GET'])
def post_unpin():
    login_redirect = _require_login()
    if login_redirect:
        return login_redirect

    user_conn = get_user_db_connection()
    user_c = user_conn.cursor()
    user_c.execute(
        "UPDATE users SET pinned_post_id = NULL WHERE id = ?",
        (session['user_id'],),
    )
    user_conn.commit()
    user_conn.close()

    flash('Pinned post removed.')
    return redirect(url_for('post_list', post_search=request.args.get('post_search', '')))


@app.route('/post/new', methods=['GET', 'POST'])
def post_new():
    login_redirect = _require_login()
    if login_redirect:
        return login_redirect

    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        template = request.form['template']
        is_public = 1 if request.form.get('is_public') == 'on' else 0

        conn = get_post_db_connection()
        c = conn.cursor()
        c.execute(
            'INSERT INTO posts (user_id, title, content, template, is_public) VALUES (?, ?, ?, ?, ?)',
            (session['user_id'], title, content, template, is_public),
        )
        conn.commit()
        conn.close()

        return redirect(url_for('post_list'))

    return render_template('post_new.html')


@app.route('/post/<int:post_id>')
def post_view(post_id):
    conn = get_post_db_connection()
    c = conn.cursor()
    c.execute('SELECT user_id, title, content, template, is_public FROM posts WHERE id = ?', (post_id,))
    post = c.fetchone()
    conn.close()

    login_redirect = _require_login()
    if login_redirect:
        return login_redirect

    if session['username'] != os.environ.get('USERNAME', 'sliderboo'):
        return 'You are not me', 404

    if not post:
        return 'Post not found', 404

    owner_id, title, content, template, is_public = post

    if not is_public and owner_id != session['user_id']:
        return 'Post not found', 404

    template_path = f'data/templates/{template}'

    if template.startswith('/') or template.startswith('../') or not template.endswith('.html'):
        template_path = 'data/templates/default.html'

    template_path = os.path.normpath(template_path)

    if 'role' not in session or session['role'] != 'admin':
        if not template_path.startswith('data/') or '..' in template_path:
            template_path = 'data/templates/default.html'

    try:
        with open(template_path, 'r', encoding='utf-8', errors='ignore') as f:
            template_content = f.read()
    except FileNotFoundError:
        with open('data/templates/default.html', 'r', encoding='utf-8') as f:
            template_content = f.read()

    rendered_post = render_template_string(template_content, title=title, content=content)

    return rendered_post


if __name__ == '__main__':
    if not os.path.exists('templates'):
        os.makedirs('templates')
    if not os.path.exists('data/templates'):
        os.makedirs('data/templates')

    init_db()
    app_port = int(os.environ.get('APP_PORT', '5001'))
    app.run(debug=True, host='0.0.0.0', port=app_port)
