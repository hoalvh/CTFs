import os
import sqlite3

USER_DATABASE = 'data/users.db'
POST_DATABASE = 'posts.db'
USERNAME = os.environ.get('USERNAME', 'sliderboo')
PASSWORD = os.environ.get('PASSWORD', 'password')


def init_db():
    with sqlite3.connect(USER_DATABASE) as user_conn:
        user_c = user_conn.cursor()
        user_c.execute(
            '''CREATE TABLE IF NOT EXISTS users
               (id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                password TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                pinned_post_id INTEGER)'''
        )

        user_c.execute('SELECT id FROM users WHERE username = ?', (USERNAME,))
        row = user_c.fetchone()
        if row is None:
            user_c.execute(
                "INSERT INTO users (username, password, role) VALUES (?, ?, 'user')",
                (USERNAME, PASSWORD),
            )
            user_id = user_c.lastrowid
        else:
            user_id = row[0]

    with sqlite3.connect(POST_DATABASE) as post_conn:
        post_c = post_conn.cursor()
        post_c.execute(
            '''CREATE TABLE IF NOT EXISTS posts
               (id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                template TEXT DEFAULT 'default',
                is_public INTEGER NOT NULL DEFAULT 0)'''
        )

        post_c.execute('SELECT 1 FROM posts WHERE user_id = ? AND title = ?', (user_id, 'My first post'))
        if post_c.fetchone() is None:
            post_c.execute(
                'INSERT INTO posts (user_id, title, content, template, is_public) VALUES (?, ?, ?, ?, ?)',
                (user_id, 'My first post', PASSWORD, 'default', 0),
            )


def get_user_db_connection():
    conn = sqlite3.connect(USER_DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def get_post_db_connection():
    conn = sqlite3.connect(POST_DATABASE)
    conn.row_factory = sqlite3.Row
    return conn
