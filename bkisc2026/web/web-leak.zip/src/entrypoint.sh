#!/bin/sh
set -eu

cd /app
export USERNAME="sliderboo$(cat /dev/urandom | tr -dc 'a-f0-9' | fold -w 16 | head -n 1)"
export PASSWORD="BKISC{$(cat /dev/urandom | tr -dc 'a-f0-9' | fold -w 16 | head -n 1)}"
export APP_PORT=5001

python app.py &

python - <<'PY'
import socket
import sys
import time

for _ in range(60):
    try:
        with socket.create_connection(("127.0.0.1", 5001), timeout=0.5):
            sys.exit(0)
    except OSError:
        time.sleep(0.5)

print("Flask did not become ready on 127.0.0.1:5001", file=sys.stderr)
sys.exit(1)
PY

node /app/bot/bot.js &
exec nginx -g 'daemon off;'
